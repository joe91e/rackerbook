import os
import sys

sys.path.append("../Model")
#from google.appengine.api import users
import xml.etree.ElementTree as ET

from google.appengine.ext import db
from Crisis import Crisis
from People import People
from Data import Data
from Link import Link
from Organization import Organization
from datetime import date
from validation import validation

class importXML(object):
	
	def getCommonData(self, commonData, data):
		"""
			Add all data to the dictionary
		"""
		# name
		name = commonData.find('name')
		data["name"] = name.text
		# alternate names, as a list
		alternateName = commonData.find('alternate-names')
		if(alternateName != None):
		        data["alternate_name"] = alternateName.text
		# model_kind
		kind = commonData.find('kind').text
		data["model_kind"] = kind
		# description
		description = commonData.find('description')
		data["description"] = description.text
		# location
		location = commonData.find('location')
		self.getLocation(location, data)
		# media
		self.getMedia(commonData, data)
		# citations
		citations = commonData.find('citations')
		self.getCitations(citations, data)
		# external-links
		externalLinks = commonData.find('external-links')
		self.getExternalLinks(externalLinks, data)

	def getExternalLinks(self, externalLinks, data):
		if(externalLinks == None):
			return
		links = self.getListOfLinkKeys(externalLinks, 'external-link')
		data["external_links"] = links

	def getCitations(self, citations, data):
		if(citations == None):
			return
		cits = self.getListOfLinkKeys(citations, 'citation')
		data["citations"] = cits

	def getLocation(self, location, data):
		latlong = location.find('latitude-longitude')
		latitude = None
		longitude = None
		if(latlong != None):
			latitude = latlong.find('latitude')
			longitude = latlong.find('longitude')
		city    = ""
		state   = ""
		country = ""
		city    = location.find('city')
		state   = location.find('state')
		country = location.find('country')
		if(latitude != None):
			data["latitude"]  = latitude.text
		if(longitude != None):
			data["longitude"] = longitude.text
		if(city != None):
			data["city"]      = city.text
		if(state != None):	
			data["state"]     = state.text
		if(country != None):
			data["country"]   = country.text
			
	def getMedia(self, media, data):
		# images
		if(media is None) :
			return
		images = media.find('images')
		if(images is not None):
			imageKeys = self.getListOfLinkKeys(images, 'image')
			data["images"] = imageKeys
		# maps
		maps = media.find('maps')
		if(maps is not None):
			mapKeys = self.getListOfLinkKeys(maps, 'map')
			data["maps"] = mapKeys
			pass
		# videos
		videos = media.find("videos")
		if(videos is not None):
			youtubes = []
			for youtube in videos.findall("youtube"):
				youtubes.append(youtube.text)
			data["videos_youtube"] = youtubes
			vimeos = []
			for vimeo in videos.findall("vimeo"):
				vimeos.append(vimeo.text)
			data["videos_vimeo"] = vimeos
		# socials
		socials = media.find("social")
		if(socials is not None):
			facebooks = []
			for facebook  in socials.findall('facebook'):
				facebooks.append(facebook.text)
			data["social_facebook"] = facebooks
			twitters = []
			for twitter in socials.findall('twitter'):
				twitters.append(twitter.text)
			data["social_twitter"] = twitters
			youtubes = []
			for youtube in socials.findall('youtube'):
				youtubes.append(youtube.text)
			data["social_youtube"] = youtubes
			
	def getListOfLinkKeys(self, node, name):
		"""
		Args: 
			node: a node in the tree
			name: the name of child nodes which contain links.
		Returns: 
			A list of key objects for links added to the data store
			which were based on the source/descrption pairs in the XML
			
		e.g.,
		<node>
			<name>
				<source>http://...</source>
				<description>...</description>
			</name>
			<name>
				...
			</name>
			...
		<node>
		
		returns [key1, key2, ... keyN]
		"""
		nodeKeys = []
		if(node is not None):
			for child in node.findall(name):
				args = {}
				args['url'] = child.find('source').text
				assert args['url'] != None
				args['description'] = child.find('description').text
				assert args['description'] != None
				assert not "\n" in args['description'] 
				link = Link(**args)
				key = link.put()
				args['key_name'] = str(key) # save the key for search data later
				#self.saveSearchData(args)
				nodeKeys.append(key)
		return nodeKeys

	def getHumanImpact(self, humanImpact, data):
		for death in humanImpact.findall('deaths'):
			data["deaths"] = int(death.text)
		for missing in humanImpact.findall('missing'):
			data["missing"] = int(missing.text)
		for injured in humanImpact.findall("injured"):
			data["injured"] = int(injured.text)
		for displaced in humanImpact.findall("displaced"):
			data["displaced"] = int(displaced.text)

	def getResourcesNeeded(self, resNeeded, data):
		resources = []
		for resource in resNeeded.findall('resource'):
			resources.append(resource.text)
		data["resources_needed"] = resources
	
	def getWaysToHelp(self, waysToHelp, data):
		ways = []
		for way in waysToHelp.findall('way'):
			ways.append(way.text)
		data["ways_to_help"] = ways

	def getOrganizationIDREFS(self, refs, data):
		list = []
		for ID in refs.findall('organization-refs'):
			list.append(ID.text)
		data["organization_refs"] = list

	def getCrisisIDREFS(self, refs, data):
                list = []
                for ID in refs.findall('crisis-refs'):
                        list.append(ID.text)
                data["crisis_refs"] = list

	def getPersonIDREFS(self, refs, data):
                list = []
                for ID in refs.findall('person-refs'):
                        list.append(ID.text)
                data["person_refs"] = list

	def getContactInfo(self, contactInfo, data):
		for address in contactInfo.findall('address'):
			data["address"] = address.text
		for email in contactInfo.findall('email'):
			data["email"] = email.text
		for phone in contactInfo.findall('phone'):
			data["phone"] = phone.text

	
	def createCrisisModel(self, crisis):
		"""
		Add all data do the dictionary and then pass that to the constructor
		"""
		data = {}
		# common-data
		#commonData = crisis.find('common-data')
		self.getCommonData(crisis, data)
		# start-date
		startDate = crisis.find('start-date')
		if(startDate is not None) :
			data["start_date"] = startDate.text
		# end-date
		endDate = crisis.find('end-date')
		if(endDate is not None) :
			data["end_date"] = endDate.text
		# human-impact
		humanImpact = crisis.find('human-impact')
		self.getHumanImpact(humanImpact, data)
		# economic-impact
		economicImpact = crisis.find('economic-impact')
		data["economic_impact"] = int(economicImpact.text)
		# resources-needed
		resourcesNeeded = crisis.find('resources-needed')
		self.getResourcesNeeded(resourcesNeeded, data)
		# ways-to-help
		waysToHelp = crisis.find('ways-to-help')
		self.getWaysToHelp(waysToHelp, data)
		# organization-refs
		self.getOrganizationIDREFS(crisis, data)		
		# person-refs
		self.getPersonIDREFS(crisis, data)
		# model_id
		model_id = crisis.get('id')
		data["model_id"] = model_id
				
		# check against name
		rows = db.GqlQuery("SELECT * FROM Crisis WHERE name='" + data['name'] + "'").fetch(None)
		if len(rows) > 0:
			data['model_id'] = str(rows[0].model_id)

		#self.printDictionary(data)
		
		# At this point, all the information has been read into a dictionary object
		# (data) and can be passed by argument name to a method that will
		# create the model object
		
		#assert type(data['images']) == list.type
		#assert type(data['maps']) == list
		#assert type(data['citations']) == list
		
		data['key_name'] = data['model_id']
		self.saveSearchData(data)
		c = Crisis(**data)
		c.put()
		return c

	def createPersonModel(self, person):
		data = {}
		# common-data
		#commonData = person.find('common-data')
		self.getCommonData(person, data)
		# organization-refs
		self.getOrganizationIDREFS(person, data)
		# crisis-refs
		self.getPersonIDREFS(person, data)
		# model_id
		model_id = person.get('id')
		data["model_id"] = model_id
		
		# check against name
		rows = db.GqlQuery("SELECT * FROM People WHERE name='" + data['name'] + "'").fetch(None)
		if len(rows) > 0:
			data['model_id'] = str(rows[0].model_id)
		
		#self.printDictionary(data)
		data['key_name'] = data['model_id']
		self.saveSearchData(data)
		p = People(**data)
		p.put()
		return p

	def createOrgModel(self, org):
		data = {}
		# common-data
		#commonData = org.find('common-data')
		self.getCommonData(org, data)
		# contact-info
		self.getContactInfo(org, data)
		# crisis-refs
		self.getCrisisIDREFS(org, data)
		# person-refs
		self.getPersonIDREFS(org, data)
		# model_id
		model_id = org.get('id')
		data["model_id"] = model_id
		
		# check against name
		rows = db.GqlQuery("SELECT * FROM Organization WHERE name='" + data['name'] + "'").fetch(None)
		if len(rows) > 0:
			data['model_id'] = str(rows[0].model_id)

		#self.printDictionary(data)
		data['key_name'] = data['model_id']
		self.saveSearchData(data)
		o = Organization(**data)
		o.put()
		return o

	def createModels(self, root):
		"""
		Create GAE models based on the tree created from the XML
		"""
		crises = root.find('crises')
		people = root.find('people')
		orgs   = root.find('organizations')
		
		models = []
		for crisis in crises.findall('crisis'):
			model = self.createCrisisModel(crisis)
			models.append(model)
		for person in people.findall('person'):
			model = self.createPersonModel(person)
			models.append(model)
		for org    in orgs.findall('organization'):
			model = self.createOrgModel(org)
			models.append(model)
		return models

	def saveSearchData(self, data):
		model = self.getDataModel()
		data_key = data['key_name']
		filter = ['name', 'alternate_names', 'description', 'city', 'state', 'country', 'start_date', 'end_date', 'ways_to_help', 'resources_needed', 'address', 'e_mail', 'phone']
		for (a, b) in data.items():
			# check if item already exists. If not, add it
			# model is effectively a list of tuples of the
			# form (text, field name, model key)
			x = (b, a, data_key) # (text, keyword, model_key)
			if((not model.contains(x)) and (a in filter)):
				# Note all fields should be lists of strings or strings
				if(type(b) == str) :
					model.append_tuple(x)
				if(type(b) == list) :
					for s in b:
						model.append_tuple((s, a, data_key))
		model.put()
	
	def getDataModel(self):
		rows = db.GqlQuery("SELECT * FROM Data").fetch(None)
		assert len(rows) <= 1
		if(len(rows) == 0):
			return Data()
		data = rows[0]
		return data

	def importDocuments(self, filename) :
		"""
			Import xml from documents, parse and put into Google Models
		"""
		v = validation()
		test_xml = filename
		test_xsd = "WC.xsd"
		if(v.validateXSD(test_xml, test_xsd)):
			tree = ET.parse(filename)
			root = tree.getroot()
			self.createModels(root)
		else:
			print 'Content-Type: text/text'
			print ''
			print 'XML failed to parse'

	def importDocumentsFile(self, file) :
		"""
			Import xml from documents, parse and put into Google Models
		"""
		v = validation()
		test_xsd = "../WC.xsd"
		if(v.validateXSDString(file, test_xsd)):
			tree = ET.fromstring(file)
			self.createModels(tree)
			return True
		else:
			return False