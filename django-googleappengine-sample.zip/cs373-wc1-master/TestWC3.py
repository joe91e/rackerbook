#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os
sys.path.append("/Applications/GoogleAppEngineLauncher.app/Contents/Resources/GoogleAppEngine-default.bundle/Contents/Resources/google_appengine")
sys.path.append("./test")
sys.path.append("./Model")

import StringIO
import unittest

# To create a new test File add import your test here
import TestPeopleModel
import TestCrisisModel
import TestOrganizationModel
import TestMiniXsv
import TestImport
import TestImport2
import TestExport
import TestServer
import TestCommonModel
import TestSearchHelper
import TestSearchFc

# ----
# main
# ----

print "TestWC3.py"

# Create Loader and Suite
loader = unittest.TestLoader()
suite = loader.loadTestsFromModule(TestMiniXsv)

# Add tests to Suite
suite.addTests(loader.loadTestsFromModule(TestImport))
suite.addTests(loader.loadTestsFromModule(TestImport2))
suite.addTests(loader.loadTestsFromModule(TestExport))
suite.addTests(loader.loadTestsFromModule(TestSearchHelper))
suite.addTests(loader.loadTestsFromModule(TestSearchFc))
suite.addTests(loader.loadTestsFromModule(TestCommonModel))
suite.addTests(loader.loadTestsFromModule(TestCrisisModel))
suite.addTests(loader.loadTestsFromModule(TestPeopleModel))
suite.addTests(loader.loadTestsFromModule(TestOrganizationModel))
suite.addTests(loader.loadTestsFromModule(TestServer))

# Run tests
unittest.TextTestRunner(verbosity=2).run(suite)

print "Done."
