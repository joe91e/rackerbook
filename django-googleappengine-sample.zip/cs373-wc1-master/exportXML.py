#from importXML import importXML
from google.appengine.ext import db
from xml.etree.ElementTree import Element, SubElement, Comment, tostring, ElementTree, dump
from Crisis import Crisis
from People import People
from Organization import Organization
from Link import Link

class exportXML(object):

    def exportDocuments(self) :
	tree = createTree()
	s = tostring(tree, encoding="us-ascii")
	f = open("output.xml", "w")
	f.write(s)


    def getXML(self) :
        """
            Returnt the xml string to display
        """
        #db.delete(Crisis.all(keys_only=True))
        #db.delete(People.all(keys_only=True))
        #db.delete(Organization.all(keys_only=True))
        #db.delete(Link.all(keys_only=True))
        tree = self.createTree()
	s = tostring(tree, encoding="us-ascii")
	print s	
        

    def createTree(self):
	people = db.GqlQuery("SELECT * FROM People").fetch(None)
	orgs   = db.GqlQuery("SELECT * FROM Organization").fetch(None)
	crises = db.GqlQuery("SELECT * FROM Crisis").fetch(None)

	world_crisis = Element('world-crises')
	crisis_node = SubElement(world_crisis, 'crises')
	org_node = SubElement(world_crisis, 'organizations')
	people_node = SubElement(world_crisis, 'people')
		
	for crisis in crises:
		c = SubElement(crisis_node, "crisis")
		self.populateCrisis(c, crisis)
	for org in orgs:
		o = SubElement(org_node, "organization")
		self.populateOrganization(o, org)
	for person in people:
		p = SubElement(people_node, "person")
		self.populatePerson(p, person)
	return world_crisis
	
    def populateCrisis(self, crisis_node, crisis_model):
	self.populateID(crisis_node, crisis_model)
	self.populateCommonData(crisis_node, crisis_model)
	self.populateStartDate(crisis_node, crisis_model)
	self.populateEndDate(crisis_node, crisis_model)
	self.populateHumanImpact(crisis_node, crisis_model)
	self.populateEconomicImpact(crisis_node, crisis_model)
	self.populateResourcesNeeded(crisis_node, crisis_model)
	self.populateWaysToHelp(crisis_node, crisis_model)
	self.populateOrganizationRefs(crisis_node, crisis_model)
	self.populatePersonRefs(crisis_node, crisis_model)
        s = tostring(crisis_node, encoding="us-ascii")


    def populateOrganization(self, org_node, org_model):
	self.populateID(org_node, org_model)
	self.populateCommonData(org_node, org_model)
	self.populateContactInfo(org_node, org_model)
	self.populateCrisisRefs(org_node, org_model)
	self.populatePersonRefs(org_node, org_model)
        s = tostring(org_node, encoding="us-ascii")


    def populatePerson(self, person_node, person_model):
	self.populateID(person_node, person_model)
	self.populateCommonData(person_node, person_model)
	self.populateCrisisRefs(person_node, person_model)
	self.populateOrganizationRefs(person_node, person_model)
	s = tostring(person_node, encoding="us-ascii")
	
    def populateCommonData(self, obj, model):
	# Common data
	# name
	if(model.name != None):
		name=SubElement(obj, "name")
		name.text = model.name
	# alternate names
	if(model.alternate_names != None):
		alternate_names=SubElement(obj, "alternate-names")
		alternate_names.text = model.alternate_names
	# kind
	if(model.model_kind != None):
		kind=SubElement(obj, "kind")
		kind.text = model.model_kind
	# description
	if(model.description != None):
		description = SubElement(obj, "description")
		description.text = model.description
	
	# location
	location = SubElement(obj, "location")
	# latitude
	if(model.latitude != None):
		latitude = SubElement(location, "latitude")
		latitude.text = model.latitude
	# longitude
	if(model.longitude != None):
		longitude = SubElement(location, "longitude")
		longitude.text = model.longitude
	# city
	if(model.city != None):
		city = SubElement(location, "city")
		city.text = model.city
	# state
	if(model.state != None):
		state = SubElement(location, "state")
		state.text = model.state
	# country
	if(model.country != None):
		country = SubElement(location, "country")
		country.text = model.country
	# Media
	# Images
	if(model.images != None):
		images = SubElement(obj, "images")
		for imageKey in model.images:
			link = db.get(imageKey)
			image = SubElement(images, "image")
			
			source = link.url
			text = link.description
			url = SubElement(image, "source")
			description = SubElement(image, "description")
			url.text = source
			description.text = text
			
	# Maps
	if(model.maps != None):
		maps = SubElement(obj, "maps")
		for mapKey in model.maps:
			link =  db.get(mapKey)
			map = SubElement(maps, "map")
			
			source = link.url
			text = link.description
			source = link.url
			text = link.description
			url = SubElement(map, "source")
			description = SubElement(map, "description")
			url.text = source
			description.text = text
			
	# Videos youtube
	videos = SubElement(obj, "videos")
	if(model.videos_youtube != None):
		for youtubeText in model.videos_youtube:
			youtube = SubElement(videos, "youtube")
			youtube.text = youtubeText
	# Videos vimeo
	if(model.videos_vimeo != None):
		for vimeoText in model.videos_vimeo:
			vimeo = SubElement(videos, "vimeo")
			vimeo.text = vimeoText
	# Social
	social = SubElement(obj, "social")
	if(model.social_facebook != None):
		for facebookText in model.social_facebook:
			facebook = SubElement(social, "facebook")
			facebook.text = facebookText
	if(model.social_twitter != None):
		for twitterText in model.social_twitter:
			twitter = SubElement(social, "twitter")
			twitter.text = twitterText
	if(model.social_youtube != None):
		for youtubeText in model.social_youtube:
			youtube = SubElement(social, "youtube")
			youtube.text = youtubeText
	# citations
	citations = SubElement(obj, "citations")
	if(model.citations != None):
		for citationKey in model.citations:
			link = db.get(citationKey)
			citation = SubElement(citations, "citation")
			
			source = link.url
			text = link.description
			source = link.url
			text = link.description
			url = SubElement(citation, "source")
			description = SubElement(citation, "description")
			url.text = source
			description.text = text
			
        # external_links
        external_links = SubElement(obj, "external-links")
	if(model.external_links != None):
		for extLinkKey in model.external_links:
			link = db.get(extLinkKey)
			external_link = SubElement(external_links, "external-link")
			
			source = link.url
			text = link.description
			url = SubElement(external_link, "source")
			description = SubElement(external_link, "description")
			url.text = source
			description.text = text

    def populateStartDate(self, obj, model):
        # start date
	if(model.start_date != None):
                start_date = SubElement(obj, "start-date")
                start_date.text = model.start_date

    def populateEndDate(self, obj, model):
	# end date
	if(model.end_date != None):
                end_date = SubElement(obj, "end-date")
                end_date.text = model.end_date

    def populateHumanImpact(self, obj, model):
		# Human Impact
		human_impact = SubElement(obj, "human-impact")
		# deaths
		if(model.deaths != None):
			deaths = SubElement(human_impact, "deaths")
			deaths.text = str(model.deaths)
		# missing
		if(model.missing != None):
			missing = SubElement(human_impact, "missing")
			missing.text = str(model.missing)
		# injured
		if(model.injured != None):
			injured = SubElement(human_impact, "injured")
			injured.text = str(model.injured)
		# displaced
		if(model.displaced != None):
			displaced = SubElement(human_impact, "displaced")
			displaced.text = str(model.displaced)

    def populateEconomicImpact(self, obj, model):
	# economic_impact
	if(model.economic_impact != None):
		economic_impact = SubElement(obj, "economic-impact")
		economic_impact.text = str(model.economic_impact)

    def populateWaysToHelp(self, obj, model):
	# ways_to_help
	ways_to_help = SubElement(obj, "ways-to-help")
	if(model.ways_to_help != None):
		for wayText in model.ways_to_help:
			way = SubElement(ways_to_help, "way")
			way.text = wayText

    def populateResourcesNeeded(self, obj, model):
	# resources_needed
	resources_needed = SubElement(obj, "resources-needed")
	if(model.resources_needed != None):
		for resourceText in model.resources_needed:
			resource = SubElement(resources_needed, "resource")
			resource.text = resourceText

    def populateOrganizationRefs(self, obj, model):
	# organization_refs
	if(model.organization_refs != None):
		for orgText in model.organization_refs:
			organization = SubElement(obj, "organization-refs")
			organization.text = orgText

    def populatePersonRefs(self, obj, model):
	# person_refs
	if(model.person_refs != None):
		for personText in model.person_refs:
			person = SubElement(obj, "person-refs")
			person.text = personText

    def populateCrisisRefs(self, obj, model):
	# crisis_refs
	if(model.crisis_refs != None):
		for crisisText in model.crisis_refs:
			crisis = SubElement(obj, "crisis-refs")
			crisis.text = crisisText

    def populateModelID(self, obj, model):
	# model_id
	if(model.model_id != None):
		model_id = SubElement(obj, "model-id")
		model_id.text = model.model_id

    def populateContactInfo(self, obj, model):
	# address
	if(model.address != None):
		address = SubElement(obj, "address")
		address.text = model.address
	# e_mail
	if(model.e_mail != None):
		e_mail = SubElement(obj, "e_email")
		e_mail.text = model.e_mail
	# phone
	if(model.phone != None):
		phone = SubElement(obj, "phone")
		phone.text = model.phone
	
    def populateID(self, obj, c):
	obj.attrib = {'id':c.model_id}
