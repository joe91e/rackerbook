import sys
import os

sys.path.append('Model')

from google.appengine.ext import db

from exportXML import exportXML

print 'Content-Type: text/xml'
print ''

e = exportXML()
e.getXML()