#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os
import os.path
sys.path.append("..")
sys.path.append("./Model")

import StringIO
import unittest
import Crisis
from google.appengine.ext import db
from validation import validation


class TestMiniXsv (unittest.TestCase) :

    def test_validate_1 (self) :
        v = validation()
        test_xml = "test/resources/xml/test_xml_1.xml"
        test_xsd = "test/resources/xsd/test_xsd_1.xsd"
        self.assertTrue(os.path.isfile(test_xml))
        self.assertTrue(os.path.isfile(test_xsd))
        self.assertTrue(v.validateXSD(test_xml, test_xsd))

    def test_validate_2 (self) :
        v = validation()
        test_xml = "test/resources/xml/test_xml_2.xml"
        test_xsd = "test/resources/xsd/test_xsd_2.xsd"
        self.assertTrue(os.path.isfile(test_xml))
        self.assertTrue(os.path.isfile(test_xsd))
        self.assertTrue(v.validateXSD(test_xml, test_xsd))

    def test_validate_xsd_3 (self) :
        v = validation()
        test_xml = "test/resources/xml/test_xml_3.xml"
        test_xsd = "test/resources/xsd/test_xsd_3.xsd"
        self.assertTrue(os.path.isfile(test_xml))
        self.assertTrue(os.path.isfile(test_xsd))
        self.assertTrue(v.validateXSD(test_xml, test_xsd))
	
    def test_validate_real_doc (self) :
        v = validation()
        test_xml = "world-crises.xml"
        test_xsd = "WC.xsd"
        self.assertTrue(os.path.isfile(test_xml))
        self.assertTrue(os.path.isfile(test_xsd))
        self.assertTrue(v.validateXSD(test_xml, test_xsd))

	
    def test_validate_test_doc (self) :
        v = validation()
        test_xml = "wc-sample.xml"
        test_xsd = "WC.xsd"
        self.assertTrue(os.path.isfile(test_xml))
        self.assertTrue(os.path.isfile(test_xsd))
        self.assertTrue(v.validateXSD(test_xml, test_xsd))

	def test_validate_test_doc_zombie (self) :
		v = validation()
		test_xml = "WWZ.xml"
		test_xsd = "WC.xsd"
		self.assertTrue(os.path.isfile(test_xml))
		self.assertTrue(os.path.isfile(test_xsd))
		self.assertTrue(v.validateXSD(test_xml, test_xsd))
        
