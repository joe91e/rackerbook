#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
	To test the program:
	% python TestImport.py >& TestImport.out
	% chmod ugo+x TestImport.py
	% TestImport.py >& TestImport.out
"""

from xml.etree.ElementTree import Element, SubElement, Comment, tostring, ElementTree, dump

# -------
# imports
# -------

import sys
import os

sys.path.append("..")

import StringIO
import unittest
from importXML import *
from exportXML import *
import xml.etree.ElementTree as ET

import People
import Organization
import Crisis

from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

# using test/outline_test.xml

class TestExport (unittest.TestCase) :
	
	
	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
		x = importXML()
		x.importDocuments("world-crises.xml")
	
	def tearDown(self):
		self.testbed.deactivate()
	
	def test_populateContactInfo_1 (self):
		people = db.GqlQuery("SELECT * FROM Organization where name='USCG'").fetch(None)
		p = people[0]
		top_expected = Element("contact");
		top_gotten = Element("contact");
		address = SubElement(top_expected, "address")
		address.text = p.address
		if(p.e_mail is not None):
			e_mail = SubElement(top_expected, "e_email")
			e_mail.text = p.e_mail
		phone = SubElement(top_expected, "phone")
		phone.text = p.phone
		x = exportXML()
		x.populateContactInfo(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populateContactInfo_2 (self):
		people = db.GqlQuery("SELECT * FROM Organization where name='UNICEF'").fetch(None)
		p = people[0]
		top_expected = Element("contact");
		top_gotten = Element("contact");
		if(p.address is not None):
			address = SubElement(top_expected, "address")
			address.text = p.address
		if(p.e_mail is not None):
			e_mail = SubElement(top_expected, "e_email")
			e_mail.text = p.e_mail
		if(p.phone is not None):
			phone = SubElement(top_expected, "phone")
			phone.text = p.phone
		x = exportXML()
		x.populateContactInfo(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populateContactInfo_3 (self):
		people = db.GqlQuery("SELECT * FROM Organization where name='Water.org'").fetch(None)
		p = people[0]
		top_expected = Element("contact");
		top_gotten = Element("contact");
		if(p.address is not None):
			address = SubElement(top_expected, "address")
			address.text = p.address
		if(p.e_mail is not None):
			e_mail = SubElement(top_expected, "e_email")
			e_mail.text = p.e_mail
		if(p.phone is not None):
			phone = SubElement(top_expected, "phone")
			phone.text = p.phone
		x = exportXML()
		x.populateContactInfo(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populateModelID_1 (self):
		people = db.GqlQuery("SELECT * FROM Organization where name='Water.org'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.address is not None):
			address = SubElement(top_expected, "model-id")
			address.text = p.model_id
		x = exportXML()
		x.populateModelID(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populateModelID_2 (self):
		people = db.GqlQuery("SELECT * FROM Organization where name='UNICEF'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.address is not None):
			address = SubElement(top_expected, "model-id")
			address.text = p.model_id
		x = exportXML()
		x.populateModelID(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populateModelID_3 (self):
		people = db.GqlQuery("SELECT * FROM Organization where name='USCG'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.address is not None):
			address = SubElement(top_expected, "model-id")
			address.text = p.model_id
		x = exportXML()
		x.populateModelID(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
	
	def test_populateCrisisRefs_1 (self):
		people = db.GqlQuery("SELECT * FROM People where name='Yingluck Shinawatra'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.crisis_refs != []):
			address = SubElement(top_expected, "crisis-refs")
			address.text = p.crisis_refs
		x = exportXML()
		x.populateCrisisRefs(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
	
	def test_populateCrisisRefs_2 (self):
		people = db.GqlQuery("SELECT * FROM People where name='George H.W. Bush'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.crisis_refs != []):
			address = SubElement(top_expected, "crisis-refs")
			address.text = p.crisis_refs
		x = exportXML()
		x.populateCrisisRefs(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
	
	def test_populateCrisisRefs_3 (self):
		people = db.GqlQuery("SELECT * FROM People where name='George H.W. Bush'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.crisis_refs != []):
			address = SubElement(top_expected, "crisis-refs")
			address.text = p.crisis_refs
		x = exportXML()
		x.populateCrisisRefs(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
	
	def test_populateOrganizationRefs_1 (self):
		people = db.GqlQuery("SELECT * FROM People where name='Arnold Schwarzenegger'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.organization_refs != []):
			address = SubElement(top_expected, "organization-refs")
			address.text = p.organization_refs
		x = exportXML()
		x.populateOrganizationRefs(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
	
	def test_populateOrganizationRefs_2 (self):
		people = db.GqlQuery("SELECT * FROM People where name='George H.W. Bush'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.organization_refs != []):
			address = SubElement(top_expected, "organization-refs")
			address.text = p.organization_refs
		x = exportXML()
		x.populateOrganizationRefs(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
	
	def test_populateOrganizationRefs_3 (self):
		people = db.GqlQuery("SELECT * FROM People where name='Matt Damon'").fetch(None)
		p = people[0]
		top_expected = Element("org");
		top_gotten = Element("org");
		if(p.organization_refs != []):
			address = SubElement(top_expected, "organization-refs")
			address.text = p.organization_refs[0]
		x = exportXML()
		x.populateOrganizationRefs(top_gotten, p)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))
		
	def test_populatePersonRefs_1 (self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		top_expected = Element("org")
		top_gotten = Element("org")
		if(c.person_refs != []):
			address = SubElement(top_expected, "person-refs")
			address.text = c.person_refs[0]
		x = exportXML()
		x.populatePersonRefs(top_gotten, c)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populatePersonRefs_2 (self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		top_expected = Element("org")
		top_gotten = Element("org")
		if(c.person_refs != []):
			address = SubElement(top_expected, "person-refs")
			address.text = c.person_refs[0]
		x = exportXML()
		x.populatePersonRefs(top_gotten, c)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))

	def test_populatePersonRefs_3 (self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		top_expected = Element("org")
		top_gotten = Element("org")
		if(c.person_refs != []):
			address = SubElement(top_expected, "person-refs")
			address.text = c.person_refs[0]
		x = exportXML()
		x.populatePersonRefs(top_gotten, c)
		self.assertEquals(tostring(top_expected), tostring(top_gotten))		
		
	def test_populateResourcesNeeded_1(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		xpected = ET.fromstring("<crisis><resources-needed><resource>Basic needs goods i.e. toiletries</resource><resource>Food</resource><resource>water</resource></resources-needed></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateResourcesNeeded(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))	
		
	def test_populateResourcesNeeded_1(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><resources-needed><resource>Cleanup teams</resource><resource>flood mitigation projects</resource><resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource><resource>life vests</resource><resource>pvc pipe for rafts</resource><resource>industrial water pumps</resource><resource>shelter</resource><resource>ways to restore damaged infrastructure</resource><resource>at least 1.5 million sandbags</resource><resource>mosquito nets</resource></resources-needed></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateResourcesNeeded(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))	
		
	def test_populateResourcesNeeded_2(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><resources-needed><resource>shelter</resource><resource>medical care</resource><resource>food </resource><resource>water</resource><resource>clothing</resource><resource>counseling for displaced victims</resource><resource>funds to help rebuild homes</resource><resource>help finding employment for those who left there jobs</resource><resource>funds for counseling</resource></resources-needed></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateResourcesNeeded(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateResourcesNeeded_3(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><resources-needed><resource>Basic needs goods i.e. toiletries</resource><resource>Food</resource><resource>water</resource></resources-needed></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateResourcesNeeded(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateWaysToHelp_1(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><ways-to-help><way>donate to Thai Red Cross</way></ways-to-help></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateWaysToHelp(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
	
	def test_populateWaysToHelp_2(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><ways-to-help><way>donate money to American Red Cross</way></ways-to-help></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateWaysToHelp(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateWaysToHelp_3(self) :
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><ways-to-help><way>Donate clothes through the Salvation army</way><way>Donate food and water through the same</way></ways-to-help></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateWaysToHelp(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateEconomicImpact_1(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><economic-impact>45000000000</economic-impact></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateEconomicImpact(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateEconomicImpact_2(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><economic-impact>3300000</economic-impact></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateEconomicImpact(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateEconomicImpact_3(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><economic-impact>25000000000</economic-impact></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateEconomicImpact(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
	
	def test_populateHumanImpact_1(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><human-impact><deaths>815</deaths><missing>0</missing><injured>720000</injured><displaced>2400000000</displaced></human-impact></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateHumanImpact(gotten, c)
		self.assertEquals(expected.find('human-impact').find('injured').text, gotten.find('human-impact').find('injured').text)
		
	def test_populateHumanImpact_2(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><human-impact><deaths>0</deaths><missing>0</missing><injured>0</injured><displaced>8000</displaced></human-impact></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateHumanImpact(gotten, c)
		self.assertEquals(expected.find('human-impact').find('missing').text, gotten.find('human-impact').find('missing').text)
		
	def test_populateHumanImpact_3(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><human-impact><deaths>41</deaths><missing>0</missing><displaced>300000</displaced></human-impact></crisis>")
		gotten = Element("crisis")
		
		assert c.displaced == 300000
		x = exportXML()
		x.populateHumanImpact(gotten, c)
		self.assertEquals(expected.find('human-impact').find('deaths').text, gotten.find('human-impact').find('deaths').text)
		
	def test_populateHumanImpact_4(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><human-impact><deaths>0</deaths><missing>0</missing><injured>0</injured><displaced>8000</displaced></human-impact></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateHumanImpact(gotten, c)
		self.assertEquals(expected.find('human-impact').find('injured').text, gotten.find('human-impact').find('injured').text)
		
		
	def test_populateEndDate_1(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><end-date>2012-01-01T12:00:00</end-date></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateEndDate(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateEndDate_2(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><end-date>1992-08-28T12:00:00</end-date></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateEndDate(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateStartDate_1(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><start-date>2011-06-01T12:00:00</start-date></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateStartDate(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateStartDate_2(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><start-date>1992-08-24T12:00:00</start-date></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateStartDate(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
		
	def test_populateStartDate_3(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><start-date>2010-10-10T12:00:00</start-date></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateStartDate(gotten, c)
		self.assertEquals(tostring(expected), tostring(gotten))
	"""
	# Note sure why, but this test doesn't work.
	def test_populateCommonData_1(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><name>2011 Thailand floods</name><kind>Natural Disaster</kind><description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description><location><country>Thailand and Cambodia</country></location><maps><map><source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source><description>Thai Flood Map</description></map><map><source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source><description>Thai Flood Map</description></map></maps><videos><youtube>tWXnIXvHhCs</youtube></videos><social><facebook>ThaiFloodEng</facebook><twitter>@thaifloodeng</twitter></social><citations><citation><source>http://www.nytimes.com/</source><description>New York Times</description></citation><citation><source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source><description>Wikipedia article for this object</description></citation><citation><source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source><description>Google Crisis Response</description></citation><citation><source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source><description>Thailand Flood Reaches Bangkok</description></citation><citation><source>http://www.bbc.co.uk/news/world/</source><description>BBC News</description></citation><citation><source>http://www.theatlantic.com/</source><description>The Atlantic</description></citation><citation><source>http://www.cnn.com/</source><description>CNN</description></citation><citation><source>http://www.huffingtonpost.com/</source><description>Huffington Post</description></citation><citation><source>http://globalvoicesonline.org/</source><description>Global Voices Online</description></citation><citation><source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source><description>Google Crisis Response</description></citation><citation><source>http://www.washingtonpost.com/</source><description>Washingtonpost.com</description></citation><citation><source>http://www.guardiannews.com/</source><description>Guardian UK</description></citation><citation><source>http://www.unicef.org/</source><description>UNICEF</description></citation></citations><external-links><external-link><source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source><description>Worst Flooding in Decades</description></external-link> <external-link><source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source><description>Disastrous Slow Moving Flood</description></external-link><external-link><source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source><description>Thailand Flood Reaches Bangkok</description></external-link><external-link><source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source><description>Thailand Flooding Death Toll</description></external-link><external-link><source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source><description>BBC Article</description></external-link><external-link><source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source><description>Reuters Article</description></external-link><external-link><source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source><description>Bangkok Flooding Waters</description></external-link></external-links></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		
		self.assertEquals(tostring(gotten), tostring(expected))
	"""	
		
	def test_populateCommonData_2(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><name>2011 Thailand floods</name></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("name")), tostring(expected.find("name")))
	
	def test_populateCommonData_3(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><kind>Natural Disaster</kind></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("kind")), tostring(expected.find("kind")))
	
	def test_populateCommonData_4(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("description")), tostring(expected.find("description")))
	
	def test_populateCommonData_5(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><maps><map><source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source><description>Thai Flood Map</description></map><map><source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source><description>Thai Flood Map</description></map></maps></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("maps")), tostring(expected.find("maps")))
		
	def test_populateCommonData_6(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><videos><youtube>tWXnIXvHhCs</youtube></videos></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("videos")), tostring(expected.find("videos")))
	
	def test_populateCommonData_7(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><social><facebook>ThaiFloodEng</facebook><twitter>@thaifloodeng</twitter></social></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("social")), tostring(expected.find("social")))
		
	def test_populateCommonData_8(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><citations><citation><source>http://www.nytimes.com/</source><description>New York Times</description></citation><citation><source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source><description>Wikipedia article for this object</description></citation><citation><source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source><description>Google Crisis Response</description></citation><citation><source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source><description>Thailand Flood Reaches Bangkok</description></citation><citation><source>http://www.bbc.co.uk/news/world/</source><description>BBC News</description></citation><citation><source>http://www.theatlantic.com/</source><description>The Atlantic</description></citation><citation><source>http://www.cnn.com/</source><description>CNN</description></citation><citation><source>http://www.huffingtonpost.com/</source><description>Huffington Post</description></citation><citation><source>http://globalvoicesonline.org/</source><description>Global Voices Online</description></citation><citation><source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source><description>Google Crisis Response</description></citation><citation><source>http://www.washingtonpost.com/</source><description>Washingtonpost.com</description></citation><citation><source>http://www.guardiannews.com/</source><description>Guardian UK</description></citation><citation><source>http://www.unicef.org/</source><description>UNICEF</description></citation></citations></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		self.assertEquals(tostring(gotten.find("citations")), tostring(expected.find("citations")))
		
	def test_populateCommonData_9(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><external-links><external-link><source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source><description>Worst Flooding in Decades</description></external-link> <external-link><source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source><description>Disastrous Slow Moving Flood</description></external-link><external-link><source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source><description>Thailand Flood Reaches Bangkok</description></external-link><external-link><source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source><description>Thailand Flooding Death Toll</description></external-link><external-link><source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source><description>BBC Article</description></external-link><external-link><source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source><description>Reuters Article</description></external-link> <external-link><source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source><description>Bangkok Flooding Waters</description></external-link></external-links></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		external_links = gotten.find("external-links").findall("external-link")
		for x in range(len(c.external_links)):
			self.assertEquals(external_links[x].find("source").text, db.get(c.external_links[x]).url)
			self.assertEquals(external_links[x].find("description").text, db.get(c.external_links[x]).description)
			
		
	def test_populateCommonData_10(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis><location><country>Thailand and Cambodia</country></location></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateCommonData(gotten, c)
		assert c.country != None
		assert c.country == "Thailand and Cambodia"
		self.assertEquals(tostring(gotten.find("location")), tostring(expected.find("location")))
		
	def test_populateModelID_1(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'")
		c = crisis[0]
		expected = ET.fromstring("<crisis id=\"thai_flood\"></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateID(gotten, c)
		
		self.assertEquals(c.model_id, "thai_flood") # passes
		self.assertEquals(expected.attrib, {'id':'thai_flood'}) # passes
		self.assertEquals(gotten.attrib, {'id':'thai_flood'})
		self.assertEquals(tostring(gotten), tostring(expected))
		
	def test_populateModelID_2(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='2010 California Wildfires'")
		c = crisis[0]
		expected = ET.fromstring("<crisis id=\"california_wildfires\"></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateID(gotten, c)
		
		self.assertEquals(c.model_id, "california_wildfires")
		self.assertEquals(tostring(gotten), '<crisis id="california_wildfires" />')
		self.assertEquals(tostring(gotten), tostring(expected))
		
	def test_populateModelID_3(self):
		crisis = db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'")
		c = crisis[0]
		expected = ET.fromstring("<crisis id=\"hurricane_andrew\"></crisis>")
		gotten = Element("crisis")
		x = exportXML()
		x.populateID(gotten, c)
		
		self.assertEquals(tostring(gotten), tostring(expected))
	
	"""
	Tests:
	
	#written	test_name
	0			populateCrisis
	0			populateOrganization
	0			populatePerson
	10			populateCommonData
	3			populateStartDate
	2			populateEndDate			// Note: only 2 crises have an end date
	4			populateHumanImpact
	3			populateEconomicImpact
	3			populateWaysToHelp
	3			populateResourcesNeeded
	3 			populateOrganizationRefs
	3 			populatePersonRefs
	3 			populateCrisisRefs
	3 			populateModelID
	3 			populateContactInfo
	"""