#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys

sys.path.append("html")

import StringIO
import unittest
from Crisis import Crisis
from Organization import Organization
from People import People
from Link import Link

from wchelper import eliminateHtmlTag
from wchelper import getLinkFromName
from wchelper import getHeader
from wchelper import populateLinks

from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestServer (unittest.TestCase) :
	
	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
	
	def tearDown(self):
		self.testbed.deactivate()

	def test_wc_driver_eliminateHtmlTag_1 (self):
		temp = "hurricane"
		self.assertEqual("hurricane", eliminateHtmlTag(temp))
	
	def test_wc_driver_eliminateHtmlTag_2 (self):
		temp = "hurricane.html"
		self.assertEqual("hurricane", eliminateHtmlTag(temp))
	
	def test_wc_driver_eliminateHtmlTag_3 (self):
		temp = "hurricane_andrew.html"
		self.assertEqual("hurricane_andrew", eliminateHtmlTag(temp))
    
	def test_wc_helper_getLinkFromName_1 (self):
		self.assertEqual("/crises/hurricane", getLinkFromName("hurricane", "crises"))
	
	def test_wc_helper_getLinkFromName_2 (self):
		self.assertEqual("/crises/hurricane_andrew", getLinkFromName("hurricane andrew", "crises"))
	
	def test_wc_helper_getLinkFromName_3 (self):
		self.assertEqual("/crises/hurricane_andrew", getLinkFromName("Hurricane Andrew", "crises"))
	
	def test_wc_helper_getHeader_1 (self):
		keys = []
		c = Crisis(key_name = "hurricane",
				   name = "Andrew",
				   description = "Hurricane hit USA",
				   model_kind = "Natural Disaster",
				   economic_impact = 1,
				   country = "USA",
				   model_id = "hurricane"
				   )
		keys.append(c.put())
		c = Crisis(key_name = "flood",
				   name = "Thai",
				   description = "Flood hit Thailand",
				   model_kind = "Natural Disaster",
				   economic_impact = 1,
				   country = "Thailand",
				   model_id = "flood"
				   )
		keys.append(c.put())
		data = getHeader()
		self.assertEqual(data['crises'][0]['name'], "Thai")
		self.assertEqual(data['crises'][0]['url'], "/crises/flood")
		self.assertEqual(data['crises'][0]['description'], "Flood hit Thailand")
		self.assertEqual(data['crises'][0]['model_id'], "flood")
		self.assertEqual(data['crises'][0]['active'], True)
		self.assertEqual(data['crises'][1]['name'], "Andrew")
		self.assertEqual(data['crises'][1]['url'], "/crises/hurricane")
		self.assertEqual(data['crises'][1]['description'], "Hurricane hit USA")
		self.assertEqual(data['crises'][1]['model_id'], "hurricane")
		self.assertEqual(data['crises'][1]['active'], False)
		self.assertEqual(data['organizations'][0]['name'], "None Yet")
		self.assertEqual(data['organizations'][0]['url'], "/")
		self.assertEqual(data['people'][0]['name'], "None Yet")
		self.assertEqual(data['people'][0]['url'], "/")
	
	def test_wc_helper_getHeader_2 (self):
		keys = []
		c = People(key_name = "matt_damon",
				   name = "Matt Damon",
				   description = "Was in Good Will Hunting",
				   model_kind = "Actor",
				   country = "USA",
				   model_id = "matt_damon"
				   )
		keys.append(c.put())
		c = People(key_name = "yingluck_shinawatra",
				   name = "Yingluck Shinawatra",
				   description = "Prime Minester",
				   model_kind = "Natural Disaster",
				   economic_impact = 1,
				   country = "Thailand",
				   model_id = "yingluck_shinawatra"
				   )
		keys.append(c.put())
		data = getHeader()
		self.assertEqual(data['people'][0]['name'], "Matt Damon")
		self.assertEqual(data['people'][0]['url'], "/people/matt_damon")
		self.assertEqual(data['people'][0]['description'], "Was in Good Will Hunting")
		self.assertEqual(data['people'][0]['model_id'], "matt_damon")
		self.assertEqual(data['people'][0]['active'], True)
		self.assertEqual(data['people'][1]['name'], "Yingluck Shinawatra")
		self.assertEqual(data['people'][1]['url'], "/people/yingluck_shinawatra")
		self.assertEqual(data['people'][1]['description'], "Prime Minester")
		self.assertEqual(data['people'][1]['model_id'], "yingluck_shinawatra")
		self.assertEqual(data['people'][1]['active'], False)
		self.assertEqual(data['organizations'][0]['name'], "None Yet")
		self.assertEqual(data['organizations'][0]['url'], "/")
		self.assertEqual(data['crises'][0]['name'], "None Yet")
		self.assertEqual(data['crises'][0]['url'], "/")
	
	def test_wc_helper_getHeader_3 (self):
		keys = []
		c = Organization(key_name = "uscg",
						 name = "USCG",
						 description = "United States Coast Guard",
						 model_kind = "organization",
						 country = "USA",
						 model_id = "uscg"
						 )
		keys.append(c.put())
		c = Organization(key_name = "water_people",
						 name = "Water People",
						 description = "Giving Water to people",
						 model_kind = "organization",
						 country = "USA",
						 model_id = "water_people"
						 )
		keys.append(c.put())
		data = getHeader()
		self.assertEqual(data['organizations'][1]['name'], "Water People")
		self.assertEqual(data['organizations'][1]['url'], "/organizations/water_people")
		self.assertEqual(data['organizations'][1]['description'], "Giving Water to people")
		self.assertEqual(data['organizations'][1]['model_id'], "water_people")
		self.assertEqual(data['organizations'][1]['active'], False)
		self.assertEqual(data['organizations'][0]['name'], "USCG")
		self.assertEqual(data['organizations'][0]['url'], "/organizations/uscg")
		self.assertEqual(data['organizations'][0]['description'], "United States Coast Guard")
		self.assertEqual(data['organizations'][0]['model_id'], "uscg")
		self.assertEqual(data['organizations'][0]['active'], True)
		self.assertEqual(data['crises'][0]['name'], "None Yet")
		self.assertEqual(data['crises'][0]['url'], "/")
		self.assertEqual(data['people'][0]['name'], "None Yet")
		self.assertEqual(data['people'][0]['url'], "/")
	
	def test_wc_helper_populate_links_1 (self):
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		state = "TX"
		country = "USA"
		
		images = []
		link = Link(url = db.Link("http://www.sample.com"),
					description = "A samle URL")
		linkid = link.put()
		images.append(linkid)
		
		maps = []
		maps.append(linkid)
		
		videos_youtube = ["Id"]
		
		social_youtube = ["ID"]
		
		citations = []
		citations.append(linkid)
		external_links = []
		external_links.append(linkid)
		
		crisis_refs = ["no ref"]
		organization_refs = ["no ref"]
		model_id = "this model"
		
		c = People(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  state = state,
						  country = country,
						  images = images, 
						  maps = maps,
						  videos_youtube = videos_youtube,
						  social_youtube = social_youtube,
						  citations = citations,
						  external_links = external_links,
						  organization_refs = organization_refs,
						  crisis_refs = crisis_refs,
						  model_id = model_id
						  )
		self.assertEqual(c.images[0], linkid)
		populateLinks(c)
		self.assertEqual(len(c.imagesLinks), 1)
		self.assertEqual(c.imagesLinks[0].url, "http://www.sample.com")
		self.assertEqual(c.imagesLinks[0].description, "A samle URL")
		self.assertEqual(len(c.mapsLinks), 1)
		self.assertEqual(c.mapsLinks[0].url, "http://www.sample.com")
		self.assertEqual(c.mapsLinks[0].description, "A samle URL")
		self.assertEqual(len(c.citationsLinks), 1)
		self.assertEqual(c.citationsLinks[0].url, "http://www.sample.com")
		self.assertEqual(c.citationsLinks[0].description, "A samle URL")
		self.assertEqual(len(c.external_linksLinks), 1)
		self.assertEqual(c.external_linksLinks[0].url, "http://www.sample.com")
		self.assertEqual(c.external_linksLinks[0].description, "A samle URL")
	
	"""
    def set_up(self):
        self.application = webapp.WSGIApplication(['/', 'index.html'], debug=True)

    def test_crisis_page_1(self):
        print self.application is None
        app = TestApp(self.application)
        response = app.get('../crises/2011_floods_in_thailand.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('2011 Floods in Thailand')
    
    def test_crisis_page_2(self):
        app = TestApp(self.application)
        response = app.get('../crises/lack_of_drinkable_water_in_africa.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('Lack of Drinkable Water in Africa')

    def test_crisis_page_3(self):
        app = TestApp(self.application)
        response = app.get('../crises/2010_california_wildfires.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('2010 California Wildfire')

    def test_organization_page_1(self):
        app = TestApp(self.application)
        response = app.get('../organizations/southern_california_wildfire_relief_fund.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('Sourthern California Wildfire Relief Fund')

    def test_organization_page_2(self):
        app = TestApp(self.application)
        response = app.get('../organizations/unicef.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('UNICEF')

    def test_organization_page_3(self):
        app = TestApp(self.application)
        response = app.get('../organizations/water_org.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('water.org')

    def test_people_page_1(self):
        app = TestApp(self.application)
        response = app.get('../people/arnold_schwarzenegger.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('Arnold Schwarzenegger')

    def test_people_page_2(self):
        app = TestApp(self.application)
        response = app.get('../people/matt_damon.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('Matt Damon')

    def test_people_page_3(self):
        app = TestApp(self.application)
        response = app.get('../people/yingluck_shinawatra.html')
        self.assertEqual('200 OK', response.status)
        self.assertTrue('Yingluck Shinawatra')
    """