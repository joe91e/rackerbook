#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
	To test the program:
	% python TestImport.py >& TestImport.out
	% chmod ugo+x TestImport.py
	% TestImport.py >& TestImport.out
"""

# -------
# imports
# -------

import sys
import os

sys.path.append("..")

import StringIO
import unittest
import People
import Organization
import Crisis
from importXML import *
import xml.etree.ElementTree as ET

from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

# using test/outline_test.xml

class TestImport (unittest.TestCase) :
	
	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
	
	def tearDown(self):
		self.testbed.deactivate()
	
	def test_importDocuments_01 (self):
		x = importXML()
		x.importDocuments("wc-sample2.xml")
		rows = db.GqlQuery("SELECT * FROM Organization")
		self.assertEquals(rows.count(), 4)
		x.importDocuments("wc-sample.xml")
		rows = db.GqlQuery("SELECT * FROM Organization")
		self.assertEquals(rows.count(), 7)
	
	def test_importDocuments_00 (self):
		x = importXML()
		x.importDocuments("wc-sample2.xml")
		rows = db.GqlQuery("SELECT * FROM People")
		self.assertEquals(rows.count(), 4)
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM People")
		self.assertEquals(rows.count(), 7)
	
	def test_importDocuments_1 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Crisis WHERE name = '2011 Thailand floods'")
		self.assertTrue(rows.count() > 0)
	
	def test_importDocuments_2 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Crisis WHERE name = '2010 California Wildfires'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_3 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Crisis WHERE name = 'Huricane Andrew'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_4 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Crisis WHERE name = 'World Water shortage'")
		self.assertTrue(rows.count() > 0)

	def test_importDocuments_5 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Organization WHERE name = 'UNICEF'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_6 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Organization WHERE name = 'USCG'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_7 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Organization WHERE name = 'Water.org'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_8 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Organization WHERE name = 'California Community Foundation'")
		self.assertTrue(rows.count() > 0)

	def test_importDocuments_9 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM People WHERE name = 'Yingluck Shinawatra'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_10 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM People WHERE name = 'Matt Damon'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_11 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM People WHERE name = 'George H.W. Bush'")
		self.assertTrue(rows.count() > 0)
		
	def test_importDocuments_12 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM People WHERE name = 'Arnold Schwarzenegger'")
		self.assertTrue(rows.count() > 0)

	def test_importDocuments_13 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM Crisis WHERE name = '2011 Thailand floods'")
		self.assertEquals(rows.get().model_kind, "Natural Disaster")

	def test_getMedia_1 (self):
		x = importXML()
		data = {}
		s = """
			<media>
				<images>
					<image>
						<source>http://media.cleveland.com/nationworld_impact/photo/california-wildfires-2jpg-2ba436abbe035ace.jpg</source>
						<description>California Wildfires</description>
					</image>
				</images>
			</media>
			"""
		tree = ET.fromstring(s)
		x.getMedia(tree, data)
		self.assertEquals(u"http://media.cleveland.com/nationworld_impact/photo/california-wildfires-2jpg-2ba436abbe035ace.jpg", db.get(data['images'][0]).url)
		
	def test_getMedia_2 (self):
		x = importXML()
		data = {}
		s = """
			<elephant>
			<videos>
				<youtube>9899z9LzO2M</youtube>
			</videos>
			</elephant>
			"""
		tree = ET.fromstring(s)
		x.getMedia(tree, data)
		self.assertEquals("9899z9LzO2M", data['videos_youtube'][0])
		
	def test_getMedia_3 (self):
		x = importXML()
		data = {}
		s = """
			<elephant>
			<maps>
				<map>
					<source>http://www.esri.com/news/arcnews/fall05articles/fall05gifs/gis-volunteers/gv1-lg.jpg</source>
					<description>This map depicts the location of Coast Guard air evacuations during the early days of Hurricane Katrina rescue operations.</description>
				</map>
			</maps>
			</elephant>
			"""
		tree = ET.fromstring(s)
		x.getMedia(tree, data)
		self.assertEquals("http://www.esri.com/news/arcnews/fall05articles/fall05gifs/gis-volunteers/gv1-lg.jpg", db.get(data['maps'][0]).url)

	def test_getExternalLinks_1(self):
		x = importXML()
		data = {}
		s = """
			<external-links>
				<external-link>
					<source>http://cdfdata.fire.ca.gov/incidents/incidents_current</source>
					<description>Current Incidents</description>
				</external-link>
			</external-links>
			"""
		tree = ET.fromstring(s)
		x.getExternalLinks(tree, data)
		self.assertEquals("http://cdfdata.fire.ca.gov/incidents/incidents_current", db.get(data['external_links'][0]).url)
		
	def test_getExternalLinks_2(self):
		x = importXML()
		data = {}
		s = """
			<external-links>
				<external-link>
					<source>http://www.defensemedianetwork.com/stories/the-u-s-coast-guards-role-in-national-incident-management/</source>
					<description>The U.S. Coast Guard's role in National Incident Management</description>
				</external-link>
			</external-links>
			"""
		tree = ET.fromstring(s)
		x.getExternalLinks(tree, data)
		self.assertEquals("http://www.defensemedianetwork.com/stories/the-u-s-coast-guards-role-in-national-incident-management/", db.get(data['external_links'][0]).url)
		
	def test_getExternalLinks_3(self):
		x = importXML()
		data = {}
		s = """
			<external-links>
				<external-link>
					<source>http://www.flickr.com/photos/coast_guard/</source>
					<description>US Coast Guard flickr gallery</description>
				</external-link>
			</external-links>
			"""
		tree = ET.fromstring(s)
		x.getExternalLinks(tree, data)
		self.assertEquals("http://www.flickr.com/photos/coast_guard/", db.get(data['external_links'][0]).url)
	
	def test_getLocation_1(self):
		x = importXML()
		data = {}
		s = """
			<location>
			<city>Kansas City</city> 
			<state>MO</state>
			<country>USA</country>
			</location>
			"""
		tree = ET.fromstring(s)
		x.getLocation(tree, data)
		self.assertEquals("MO", data['state'])
		
	def test_getLocation_2(self):
		x = importXML()
		data = {}
		s = """
			<location>
			<city>Kansas City</city> 
			<state>MO</state>
			<country>USA</country>
			</location>
			"""
		tree = ET.fromstring(s)
		x.getLocation(tree, data)
		self.assertEquals("Kansas City", data['city'])
		
	def test_getLocation_3(self):
		x = importXML()
		data = {}
		s = """
			<location>
			<city>Kansas City</city> 
			<state>MO</state>
			<country>USA</country>
			</location>
			"""
		tree = ET.fromstring(s)
		x.getLocation(tree, data)
		self.assertEquals("USA", data['country'])
		
	def test_getHumanImpact_1(self):
		x = importXML()
		data = {}
		s = """
			<human-impact>
			<deaths>815</deaths>
			<missing>0</missing>
			<injured>720000</injured>
			<displaced>2400000000</displaced>
			</human-impact>
			"""
		tree = ET.fromstring(s)
		x.getHumanImpact(tree, data)
		self.assertEquals(0, data['missing'])
	
	def test_getHumanImpact_2(self):
		x = importXML()
		data = {}
		s = """
			<human-impact>
			<deaths>815</deaths>
			<missing>0</missing>
			<injured>720000</injured>
			<displaced>2400000000</displaced>
			</human-impact>
			"""
		tree = ET.fromstring(s)
		x.getHumanImpact(tree, data)
		self.assertEquals(720000, data['injured'])
		
	def test_getHumanImpact_3(self):
		x = importXML()
		data = {}
		s = """
			<human-impact>
			<deaths>815</deaths>
			<missing>0</missing>
			<injured>720000</injured>
			<displaced>2400000000</displaced>
			</human-impact>
			"""
		tree = ET.fromstring(s)
		x.getHumanImpact(tree, data)
		self.assertEquals(815, data['deaths'])
		
	def test_getWaysToHelp_1(self):
		x = importXML()
		data = {}
		s = """
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			"""
		tree = ET.fromstring(s)
		x.getWaysToHelp(tree, data)
		self.assertEquals(["donate to Thai Red Cross"], data['ways_to_help'])
		
	def test_getWaysToHelp_2(self):
		x = importXML()
		data = {}
		s = """
			<ways-to-help>
				<way>donate money to American Red Cross</way>
			</ways-to-help>
			"""
		tree = ET.fromstring(s)
		x.getWaysToHelp(tree, data)
		self.assertEquals(["donate money to American Red Cross"], data['ways_to_help'])
		
	def test_getWaysToHelp_3(self):
		x = importXML()
		data = {}
		s = """
			<ways-to-help>
				<way>Donate clothes through the Salvation army</way>
			</ways-to-help>
			"""
		tree = ET.fromstring(s)
		x.getWaysToHelp(tree, data)
		self.assertEquals(["Donate clothes through the Salvation army"], data['ways_to_help'])
	
	def test_getContactInfo_1(self):
		x = importXML()
		data = {}
		s = """
			<person>
			<address>125 Maiden Lane New York, NY 10038</address>
			</person>
			"""
		tree = ET.fromstring(s)
		x.getContactInfo(tree, data)
		self.assertEquals("125 Maiden Lane New York, NY 10038", data['address'])
		
	def test_getContactInfo_2(self):
		x = importXML()
		data = {}
		s = """
			<person>
			<email>monthlygiving@unicefusa.org</email>
			</person>
			"""
		tree = ET.fromstring(s)
		x.getContactInfo(tree, data)
		self.assertEquals("monthlygiving@unicefusa.org", data['email'])
		
	def test_getContactInfo_3(self):
		x = importXML()
		data = {}
		s = """
			<person>
			<phone>800 367-5437</phone>
			</person>
			"""
		tree = ET.fromstring(s)
		x.getContactInfo(tree, data)
		self.assertEquals("800 367-5437", data['phone'])
		
		
	def test_getCommonData_1(self):
		x = importXML()
		s = """
			<crisis id="thai_flood">
				<name>2011 Thailand floods</name>
				<kind>Natural Disaster</kind>
				<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
				<location>
					<country>Thailand and Cambodia</country>		
				</location>
				<maps>
					<map>
						<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
						<description>Thai Flood Map</description>
					</map>
					<map>
						<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
						<description>Thai Flood Map</description>
					</map>			
				</maps>
				<videos>
					<youtube>tWXnIXvHhCs</youtube>
				</videos>
				<social>
					<facebook>ThaiFloodEng</facebook>
					<twitter>@thaifloodeng</twitter>
				</social>
				<citations>
					<citation>
						<source>http://www.nytimes.com/</source>
						<description>New York Times</description>
					</citation>
					<citation>
						<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
						<description>Wikipedia article for this object</description>
					</citation>
					<citation>
						<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
						<description>Google Crisis Response</description>
					</citation>
					<citation>
						<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
						<description>Thailand Flood Reaches Bangkok</description>
					</citation>
					<citation>
						<source>http://www.bbc.co.uk/news/world/</source>
						<description>BBC News</description>
					</citation>
					<citation>
						<source>http://www.theatlantic.com/</source>
						<description>The Atlantic</description>
					</citation>
					<citation>
						<source>http://www.cnn.com/</source>
						<description>CNN</description>
					</citation>
					<citation>
						<source>http://www.huffingtonpost.com/</source>
						<description>Huffington Post</description>
					</citation>
					<citation>
						<source>http://globalvoicesonline.org/</source>
						<description>Global Voices Online</description>
					</citation>
					<citation>
						<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
						<description>Google Crisis Response</description>
					</citation>
					<citation>
						<source>http://www.washingtonpost.com/</source>
						<description>Washingtonpost.com</description>
					</citation>
					<citation>
						<source>http://www.guardiannews.com/</source>
						<description>Guardian UK</description>
					</citation>
					<citation>
						<source>http://www.unicef.org/</source>
						<description>UNICEF</description>
					</citation>
				</citations>
				<external-links>
					<external-link>
						<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
						<description>Worst Flooding in Decades</description>
					</external-link> 
					<external-link>
						<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
						<description>Disastrous Slow Moving Flood</description>
					</external-link>
					<external-link>
						<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
						<description>Thailand Flood Reaches Bangkok</description>
					</external-link>
					<external-link>
						<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
						<description>Thailand Flooding Death Toll</description>
					</external-link>
					<external-link>
						<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
						<description>BBC Article</description>
					</external-link>
					<external-link>
						<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
						<description>Reuters Article</description>
					</external-link> 
					<external-link>
						<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
						<description>Bangkok Flooding Waters</description>
					</external-link>
				</external-links>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCommonData(tree, data)
		self.assertEquals(data["name"], "2011 Thailand floods")
		
		
	def test_getCommonData_2(self):
		x = importXML()
		s = """
			<crisis id="thai_flood">
				<name>2011 Thailand floods</name>
				<kind>Natural Disaster</kind>
				<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
				<location>
					<country>Thailand and Cambodia</country>		
				</location>
				<maps>
					<map>
						<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
						<description>Thai Flood Map</description>
					</map>
					<map>
						<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
						<description>Thai Flood Map</description>
					</map>			
				</maps>
				<videos>
					<youtube>tWXnIXvHhCs</youtube>
				</videos>
				<social>
					<facebook>ThaiFloodEng</facebook>
					<twitter>@thaifloodeng</twitter>
				</social>
				<citations>
					<citation>
						<source>http://www.nytimes.com/</source>
						<description>New York Times</description>
					</citation>
					<citation>
						<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
						<description>Wikipedia article for this object</description>
					</citation>
					<citation>
						<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
						<description>Google Crisis Response</description>
					</citation>
					<citation>
						<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
						<description>Thailand Flood Reaches Bangkok</description>
					</citation>
					<citation>
						<source>http://www.bbc.co.uk/news/world/</source>
						<description>BBC News</description>
					</citation>
					<citation>
						<source>http://www.theatlantic.com/</source>
						<description>The Atlantic</description>
					</citation>
					<citation>
						<source>http://www.cnn.com/</source>
						<description>CNN</description>
					</citation>
					<citation>
						<source>http://www.huffingtonpost.com/</source>
						<description>Huffington Post</description>
					</citation>
					<citation>
						<source>http://globalvoicesonline.org/</source>
						<description>Global Voices Online</description>
					</citation>
					<citation>
						<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
						<description>Google Crisis Response</description>
					</citation>
					<citation>
						<source>http://www.washingtonpost.com/</source>
						<description>Washingtonpost.com</description>
					</citation>
					<citation>
						<source>http://www.guardiannews.com/</source>
						<description>Guardian UK</description>
					</citation>
					<citation>
						<source>http://www.unicef.org/</source>
						<description>UNICEF</description>
					</citation>
				</citations>
				<external-links>
					<external-link>
						<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
						<description>Worst Flooding in Decades</description>
					</external-link> 
					<external-link>
						<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
						<description>Disastrous Slow Moving Flood</description>
					</external-link>
					<external-link>
						<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
						<description>Thailand Flood Reaches Bangkok</description>
					</external-link>
					<external-link>
						<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
						<description>Thailand Flooding Death Toll</description>
					</external-link>
					<external-link>
						<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
						<description>BBC Article</description>
					</external-link>
					<external-link>
						<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
						<description>Reuters Article</description>
					</external-link> 
					<external-link>
						<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
						<description>Bangkok Flooding Waters</description>
					</external-link>
				</external-links>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCommonData(tree, data)
		self.assertEquals(data["country"], "Thailand and Cambodia")
		
	def test_getCommonData_3(self):
		x = importXML()
		s = """
			<crisis id="thai_flood">
				<name>2011 Thailand floods</name>
				<kind>Natural Disaster</kind>
				<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
				<location>
					<country>Thailand and Cambodia</country>		
				</location>
				<maps>
					<map>
						<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
						<description>Thai Flood Map</description>
					</map>
					<map>
						<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
						<description>Thai Flood Map</description>
					</map>			
				</maps>
				<videos>
					<youtube>tWXnIXvHhCs</youtube>
				</videos>
				<social>
					<facebook>ThaiFloodEng</facebook>
					<twitter>@thaifloodeng</twitter>
				</social>
				<citations>
					<citation>
						<source>http://www.nytimes.com/</source>
						<description>New York Times</description>
					</citation>
					<citation>
						<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
						<description>Wikipedia article for this object</description>
					</citation>
					<citation>
						<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
						<description>Google Crisis Response</description>
					</citation>
					<citation>
						<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
						<description>Thailand Flood Reaches Bangkok</description>
					</citation>
					<citation>
						<source>http://www.bbc.co.uk/news/world/</source>
						<description>BBC News</description>
					</citation>
					<citation>
						<source>http://www.theatlantic.com/</source>
						<description>The Atlantic</description>
					</citation>
					<citation>
						<source>http://www.cnn.com/</source>
						<description>CNN</description>
					</citation>
					<citation>
						<source>http://www.huffingtonpost.com/</source>
						<description>Huffington Post</description>
					</citation>
					<citation>
						<source>http://globalvoicesonline.org/</source>
						<description>Global Voices Online</description>
					</citation>
					<citation>
						<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
						<description>Google Crisis Response</description>
					</citation>
					<citation>
						<source>http://www.washingtonpost.com/</source>
						<description>Washingtonpost.com</description>
					</citation>
					<citation>
						<source>http://www.guardiannews.com/</source>
						<description>Guardian UK</description>
					</citation>
					<citation>
						<source>http://www.unicef.org/</source>
						<description>UNICEF</description>
					</citation>
				</citations>
				<external-links>
					<external-link>
						<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
						<description>Worst Flooding in Decades</description>
					</external-link> 
					<external-link>
						<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
						<description>Disastrous Slow Moving Flood</description>
					</external-link>
					<external-link>
						<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
						<description>Thailand Flood Reaches Bangkok</description>
					</external-link>
					<external-link>
						<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
						<description>Thailand Flooding Death Toll</description>
					</external-link>
					<external-link>
						<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
						<description>BBC Article</description>
					</external-link>
					<external-link>
						<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
						<description>Reuters Article</description>
					</external-link> 
					<external-link>
						<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
						<description>Bangkok Flooding Waters</description>
					</external-link>
				</external-links>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCommonData(tree, data)
		self.assertEquals(db.get(data["maps"][0]).url, "http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png")
		
	def test_getCitations_1(self):
		x = importXML()
		s = """
			<citations>
			<citation>
				<source>http://www.washingtonpost.com/</source>
				<description>Washingtonpost.com</description>
			</citation>
			<citation>
				<source>http://www.guardiannews.com/</source>
				<description>Guardian UK</description>
			</citation>
			<citation>
				<source>http://www.unicef.org/</source>
				<description>UNICEF</description>
			</citation>
			</citations>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCitations(tree, data)
		self.assertEquals(db.get(data['citations'][0]).url, "http://www.washingtonpost.com/")
	
	def test_getCitations_2(self):
		x = importXML()
		s = """
			<citations>
			<citation>
				<source>http://www.washingtonpost.com/</source>
				<description>Washingtonpost.com</description>
			</citation>
			<citation>
				<source>http://www.guardiannews.com/</source>
				<description>Guardian UK</description>
			</citation>
			<citation>
				<source>http://www.unicef.org/</source>
				<description>UNICEF</description>
			</citation>
			</citations>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCitations(tree, data)
		self.assertEquals(db.get(data['citations'][1]).url, "http://www.guardiannews.com/")
		
	def test_getCitations_3(self):
		x = importXML()
		s = """
			<citations>
			<citation>
				<source>http://www.washingtonpost.com/</source>
				<description>Washingtonpost.com</description>
			</citation>
			<citation>
				<source>http://www.guardiannews.com/</source>
				<description>Guardian UK</description>
			</citation>
			<citation>
				<source>http://www.unicef.org/</source>
				<description>UNICEF</description>
			</citation>
			</citations>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCitations(tree, data)
		self.assertEquals(db.get(data['citations'][2]).url, "http://www.unicef.org/")
		
	def test_getResourcesNeeded_1(self):
		x = importXML()
		s = """
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getResourcesNeeded(tree, data)
		self.assertEquals(data['resources_needed'][0], "Cleanup teams")
		
	def test_getResourcesNeeded_2(self):
		x = importXML()
		s = """
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getResourcesNeeded(tree, data)
		self.assertEquals(data['resources_needed'][1], "flood mitigation projects")
		
	def test_getResourcesNeeded_3(self):
		x = importXML()
		s = """
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getResourcesNeeded(tree, data)
		self.assertEquals(len(data["resources_needed"]), 10)

	def test_getPersonIDREFS_1(self):
		x = importXML()
		s = """
			<crisis>
			<person-refs>kevin_kinney</person-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getPersonIDREFS(tree, data)
		self.assertEquals(data['person_refs'][0], "kevin_kinney")
		
	def test_getPersonIDREFS_2(self):
		x = importXML()
		s = """
			<crisis>
			<person-refs>kevin_kinney</person-refs>
			<person-refs>dino_camingue</person-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getPersonIDREFS(tree, data)
		self.assertEquals(data['person_refs'][1], "dino_camingue")
		
	def test_getPersonIDREFS_3(self):
		x = importXML()
		s = """
			<crisis>
			<person-refs>kevin_kinney</person-refs>
			<person-refs></person-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getPersonIDREFS(tree, data)
		self.assertEquals(data['person_refs'][0], "kevin_kinney")
		
	def test_getCrisisIDREFS_1(self):
		x = importXML()
		s = """
			<crisis>
			<crisis-refs>big_bad_wolf</crisis-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCrisisIDREFS(tree, data)
		self.assertEquals(data['crisis_refs'][0], "big_bad_wolf")
		
	def test_getCrisisIDREFS_2(self):
		x = importXML()
		s = """
			<crisis>
			<crisis-refs>big_bad_wolf</crisis-refs>
			<crisis-refs>bad_stuff</crisis-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCrisisIDREFS(tree, data)
		self.assertEquals(data['crisis_refs'][1], "bad_stuff")
		
	def test_getCrisisIDREFS_3(self):
		x = importXML()
		s = """
			<crisis>
			<crisis-refs>big_bad_wolf</crisis-refs>
			<crisis-refs>bad_stuff</crisis-refs>
			<crisis-refs>natural_disaster</crisis-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getCrisisIDREFS(tree, data)
		self.assertEquals(data['crisis_refs'][2], "natural_disaster")
		
	def test_getOrganizationIDREFS_1(self):
		x = importXML()
		s = """
			<crisis>
			<organization-refs>organization_1</organization-refs>
			<organization-refs>organization_2</organization-refs>
			<organization-refs>organization_3</organization-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getOrganizationIDREFS(tree, data)
		self.assertEquals(data['organization_refs'][0], "organization_1")
		
	def test_getOrganizationIDREFS_2(self):
		x = importXML()
		s = """
			<crisis>
			<organization-refs>organization_1</organization-refs>
			<organization-refs>organization_2</organization-refs>
			<organization-refs>organization_3</organization-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getOrganizationIDREFS(tree, data)
		self.assertEquals(data['organization_refs'][1], "organization_2")
		
	def test_getOrganizationIDREFS_3(self):
		x = importXML()
		s = """
			<crisis>
			<organization-refs>organization_1</organization-refs>
			<organization-refs>organization_2</organization-refs>
			<organization-refs>organization_3</organization-refs>
			</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		x.getOrganizationIDREFS(tree, data)
		self.assertEquals(data['organization_refs'][2], "organization_3")
		
	def test_createCrisisModel_1(self):
		x = importXML()
		s = """
		<crisis id="thai_flood">
			<name>2011 Thailand floods</name>
			<kind>Natural Disaster</kind>
			<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
			<location>
				<country>Thailand and Cambodia</country>		
			</location>
			<maps>
				<map>
					<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
					<description>Thai Flood Map</description>
				</map>
				<map>
					<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
					<description>Thai Flood Map</description>
				</map>			
			</maps>
			<videos>
				<youtube>tWXnIXvHhCs</youtube>
			</videos>
			<social>
				<facebook>ThaiFloodEng</facebook>
				<twitter>@thaifloodeng</twitter>
			</social>
			<citations>
				<citation>
					<source>http://www.nytimes.com/</source>
					<description>New York Times</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
					<description>Wikipedia article for this object</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</citation>
				<citation>
					<source>http://www.bbc.co.uk/news/world/</source>
					<description>BBC News</description>
				</citation>
				<citation>
					<source>http://www.theatlantic.com/</source>
					<description>The Atlantic</description>
				</citation>
				<citation>
					<source>http://www.cnn.com/</source>
					<description>CNN</description>
				</citation>
				<citation>
					<source>http://www.huffingtonpost.com/</source>
					<description>Huffington Post</description>
				</citation>
				<citation>
					<source>http://globalvoicesonline.org/</source>
					<description>Global Voices Online</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.washingtonpost.com/</source>
					<description>Washingtonpost.com</description>
				</citation>
				<citation>
					<source>http://www.guardiannews.com/</source>
					<description>Guardian UK</description>
				</citation>
				<citation>
					<source>http://www.unicef.org/</source>
					<description>UNICEF</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
					<description>Worst Flooding in Decades</description>
				</external-link> 
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
					<description>Disastrous Slow Moving Flood</description>
				</external-link>
				<external-link>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</external-link>
				<external-link>
					<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
					<description>Thailand Flooding Death Toll</description>
				</external-link>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
					<description>Reuters Article</description>
				</external-link> 
				<external-link>
					<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
					<description>Bangkok Flooding Waters</description>
				</external-link>
			</external-links>
			<start-date>2011-06-01T12:00:00</start-date>
			<end-date>2012-01-01T12:00:00</end-date>
			<human-impact>
				<deaths>815</deaths>
				<missing>0</missing>
				<injured>720000</injured>
				<displaced>2400000000</displaced>
			</human-impact>
			<economic-impact>45000000000</economic-impact>
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			<person-refs>yingluck_shinawatra</person-refs>
		</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		c = x.createCrisisModel(tree)
		self.assertEquals(c.name, "2011 Thailand floods")
		
	def test_createCrisisModel_2(self):
		x = importXML()
		s = """
		<crisis id="thai_flood">
			<name>2011 Thailand floods</name>
			<kind>Natural Disaster</kind>
			<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
			<location>
				<country>Thailand and Cambodia</country>		
			</location>
			<maps>
				<map>
					<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
					<description>Thai Flood Map</description>
				</map>
				<map>
					<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
					<description>Thai Flood Map</description>
				</map>			
			</maps>
			<videos>
				<youtube>tWXnIXvHhCs</youtube>
			</videos>
			<social>
				<facebook>ThaiFloodEng</facebook>
				<twitter>@thaifloodeng</twitter>
			</social>
			<citations>
				<citation>
					<source>http://www.nytimes.com/</source>
					<description>New York Times</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
					<description>Wikipedia article for this object</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</citation>
				<citation>
					<source>http://www.bbc.co.uk/news/world/</source>
					<description>BBC News</description>
				</citation>
				<citation>
					<source>http://www.theatlantic.com/</source>
					<description>The Atlantic</description>
				</citation>
				<citation>
					<source>http://www.cnn.com/</source>
					<description>CNN</description>
				</citation>
				<citation>
					<source>http://www.huffingtonpost.com/</source>
					<description>Huffington Post</description>
				</citation>
				<citation>
					<source>http://globalvoicesonline.org/</source>
					<description>Global Voices Online</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.washingtonpost.com/</source>
					<description>Washingtonpost.com</description>
				</citation>
				<citation>
					<source>http://www.guardiannews.com/</source>
					<description>Guardian UK</description>
				</citation>
				<citation>
					<source>http://www.unicef.org/</source>
					<description>UNICEF</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
					<description>Worst Flooding in Decades</description>
				</external-link> 
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
					<description>Disastrous Slow Moving Flood</description>
				</external-link>
				<external-link>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</external-link>
				<external-link>
					<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
					<description>Thailand Flooding Death Toll</description>
				</external-link>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
					<description>Reuters Article</description>
				</external-link> 
				<external-link>
					<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
					<description>Bangkok Flooding Waters</description>
				</external-link>
			</external-links>
			<start-date>2011-06-01T12:00:00</start-date>
			<end-date>2012-01-01T12:00:00</end-date>
			<human-impact>
				<deaths>815</deaths>
				<missing>0</missing>
				<injured>720000</injured>
				<displaced>2400000000</displaced>
			</human-impact>
			<economic-impact>45000000000</economic-impact>
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			<person-refs>yingluck_shinawatra</person-refs>
		</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		c = x.createCrisisModel(tree)
		self.assertEquals(c.country, "Thailand and Cambodia")
		
	def test_createCrisisModel_3(self):
		x = importXML()
		s = """
		<crisis id="thai_flood">
			<name>2011 Thailand floods</name>
			<kind>Natural Disaster</kind>
			<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
			<location>
				<country>Thailand and Cambodia</country>		
			</location>
			<maps>
				<map>
					<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
					<description>Thai Flood Map</description>
				</map>
				<map>
					<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
					<description>Thai Flood Map</description>
				</map>			
			</maps>
			<videos>
				<youtube>tWXnIXvHhCs</youtube>
			</videos>
			<social>
				<facebook>ThaiFloodEng</facebook>
				<twitter>@thaifloodeng</twitter>
			</social>
			<citations>
				<citation>
					<source>http://www.nytimes.com/</source>
					<description>New York Times</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
					<description>Wikipedia article for this object</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</citation>
				<citation>
					<source>http://www.bbc.co.uk/news/world/</source>
					<description>BBC News</description>
				</citation>
				<citation>
					<source>http://www.theatlantic.com/</source>
					<description>The Atlantic</description>
				</citation>
				<citation>
					<source>http://www.cnn.com/</source>
					<description>CNN</description>
				</citation>
				<citation>
					<source>http://www.huffingtonpost.com/</source>
					<description>Huffington Post</description>
				</citation>
				<citation>
					<source>http://globalvoicesonline.org/</source>
					<description>Global Voices Online</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.washingtonpost.com/</source>
					<description>Washingtonpost.com</description>
				</citation>
				<citation>
					<source>http://www.guardiannews.com/</source>
					<description>Guardian UK</description>
				</citation>
				<citation>
					<source>http://www.unicef.org/</source>
					<description>UNICEF</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
					<description>Worst Flooding in Decades</description>
				</external-link> 
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
					<description>Disastrous Slow Moving Flood</description>
				</external-link>
				<external-link>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</external-link>
				<external-link>
					<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
					<description>Thailand Flooding Death Toll</description>
				</external-link>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
					<description>Reuters Article</description>
				</external-link> 
				<external-link>
					<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
					<description>Bangkok Flooding Waters</description>
				</external-link>
			</external-links>
			<start-date>2011-06-01T12:00:00</start-date>
			<end-date>2012-01-01T12:00:00</end-date>
			<human-impact>
				<deaths>815</deaths>
				<missing>0</missing>
				<injured>720000</injured>
				<displaced>2400000000</displaced>
			</human-impact>
			<economic-impact>45000000000</economic-impact>
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			<person-refs>yingluck_shinawatra</person-refs>
		</crisis>
			"""
		tree = ET.fromstring(s)
		data = {}
		c = x.createCrisisModel(tree)
		self.assertEquals(c.model_kind, "Natural Disaster")
		
	def test_createPersonModel_1(self):
		x = importXML()
		s = """
			<person id="arnold_schwarzenegger">
			<name>Arnold Schwarzenegger</name>
			<kind>Actor, Politician</kind>
			<description>Growing up in a small, isolated village in Austria, he turned to bodybuilding as his ticket to a better life. Prior to that he served a mandatory one year in the Austrian military (beginning in 1965). After conquering the world as arguably the greatest bodybuilder who ever lived, he went to America to make his name in motion pictures. Hampered by his impossible name and thick accent, success eluded him for many years. It wasn't until he found the tailor-made role of Conan that he truly came into his own as a performer. A succession of over-the-top action films made him an international box office star. By alternating violent action films with lighter, comedic fare, he has solidified his position as one of the most popular - if not the most popular - movie stars in the world. After his long, and successful movie career, he ran in the California recall. He is now the Governor of California, yet another celebrity to be elected to the position.</description>
			<location>
				<city>Los Angeles</city>
				<state>CA</state>
				<country>United States</country>
			</location>
			<images>
				<image>
					<source>http://img.dailymail.co.uk/i/pix/2007/10_04/arnieAP_468x312.jpg</source>
					<description>Overlooking the Fires</description>
				</image>
				<image>
					<source>http://www.nationalguard.mil/news/archives/2008/07/images/070908-governor_visits-full.jpg</source>
					<description>Giving a Speech</description>
				</image>
				<image>
					<source>http://www.schwarzenegger.com/images/made/assets/uploads/images/index/0730201003_608_334_c1.jpg</source>
					<description>With the Fire Department</description>
				</image>
			</images>
			<videos>
				<youtube>xEQfuTpxQEE</youtube>
				<youtube>khAMAf2-7rs</youtube>
			</videos>
			<social>
				<facebook>joinarnold</facebook>
				<twitter>@Schwarzenegger</twitter>
				<youtube>GovSchwarzenegger</youtube>
			</social>
			<citations>
				<citation>
					<source>http://en.wikipedia.org/wiki/Arnold_Schwarzenegger</source>
					<description>Wikipedia Article</description>
				</citation>
					<citation>
						<source>http://www.imdb.com/name/nm0000216/bio</source>
						<description>IMDB</description>
				</citation>
			</citations>
			<!--<organization-refs>southern_cali_wildfires_fund</organization-refs>
			<crisis-refs>california_wildfires</crisis-refs>-->
		</person>
			"""
		tree = ET.fromstring(s)
		data = {}
		p = x.createPersonModel(tree)
		self.assertEquals(p.name, "Arnold Schwarzenegger")

	def test_createPersonModel_2(self):
		x = importXML()
		s = """
			<person id="arnold_schwarzenegger">
			<name>Arnold Schwarzenegger</name>
			<kind>Actor, Politician</kind>
			<description>Growing up in a small, isolated village in Austria, he turned to bodybuilding as his ticket to a better life. Prior to that he served a mandatory one year in the Austrian military (beginning in 1965). After conquering the world as arguably the greatest bodybuilder who ever lived, he went to America to make his name in motion pictures. Hampered by his impossible name and thick accent, success eluded him for many years. It wasn't until he found the tailor-made role of Conan that he truly came into his own as a performer. A succession of over-the-top action films made him an international box office star. By alternating violent action films with lighter, comedic fare, he has solidified his position as one of the most popular - if not the most popular - movie stars in the world. After his long, and successful movie career, he ran in the California recall. He is now the Governor of California, yet another celebrity to be elected to the position.</description>
			<location>
				<city>Los Angeles</city>
				<state>CA</state>
				<country>United States</country>
			</location>
			<images>
				<image>
					<source>http://img.dailymail.co.uk/i/pix/2007/10_04/arnieAP_468x312.jpg</source>
					<description>Overlooking the Fires</description>
				</image>
				<image>
					<source>http://www.nationalguard.mil/news/archives/2008/07/images/070908-governor_visits-full.jpg</source>
					<description>Giving a Speech</description>
				</image>
				<image>
					<source>http://www.schwarzenegger.com/images/made/assets/uploads/images/index/0730201003_608_334_c1.jpg</source>
					<description>With the Fire Department</description>
				</image>
			</images>
			<videos>
				<youtube>xEQfuTpxQEE</youtube>
				<youtube>khAMAf2-7rs</youtube>
			</videos>
			<social>
				<facebook>joinarnold</facebook>
				<twitter>@Schwarzenegger</twitter>
				<youtube>GovSchwarzenegger</youtube>
			</social>
			<citations>
				<citation>
					<source>http://en.wikipedia.org/wiki/Arnold_Schwarzenegger</source>
					<description>Wikipedia Article</description>
				</citation>
					<citation>
						<source>http://www.imdb.com/name/nm0000216/bio</source>
						<description>IMDB</description>
				</citation>
			</citations>
			<!--<organization-refs>southern_cali_wildfires_fund</organization-refs>
			<crisis-refs>california_wildfires</crisis-refs>-->
		</person>
			"""
		tree = ET.fromstring(s)
		data = {}
		p = x.createPersonModel(tree)
		self.assertEquals(p.model_kind, "Actor, Politician")

	def test_createPersonModel_3(self):
		x = importXML()
		s = """
			<person id="arnold_schwarzenegger">
			<name>Arnold Schwarzenegger</name>
			<kind>Actor, Politician</kind>
			<description>Growing up in a small, isolated village in Austria, he turned to bodybuilding as his ticket to a better life. Prior to that he served a mandatory one year in the Austrian military (beginning in 1965). After conquering the world as arguably the greatest bodybuilder who ever lived, he went to America to make his name in motion pictures. Hampered by his impossible name and thick accent, success eluded him for many years. It wasn't until he found the tailor-made role of Conan that he truly came into his own as a performer. A succession of over-the-top action films made him an international box office star. By alternating violent action films with lighter, comedic fare, he has solidified his position as one of the most popular - if not the most popular - movie stars in the world. After his long, and successful movie career, he ran in the California recall. He is now the Governor of California, yet another celebrity to be elected to the position.</description>
			<location>
				<city>Los Angeles</city>
				<state>CA</state>
				<country>United States</country>
			</location>
			<images>
				<image>
					<source>http://img.dailymail.co.uk/i/pix/2007/10_04/arnieAP_468x312.jpg</source>
					<description>Overlooking the Fires</description>
				</image>
				<image>
					<source>http://www.nationalguard.mil/news/archives/2008/07/images/070908-governor_visits-full.jpg</source>
					<description>Giving a Speech</description>
				</image>
				<image>
					<source>http://www.schwarzenegger.com/images/made/assets/uploads/images/index/0730201003_608_334_c1.jpg</source>
					<description>With the Fire Department</description>
				</image>
			</images>
			<videos>
				<youtube>xEQfuTpxQEE</youtube>
				<youtube>khAMAf2-7rs</youtube>
			</videos>
			<social>
				<facebook>joinarnold</facebook>
				<twitter>@Schwarzenegger</twitter>
				<youtube>GovSchwarzenegger</youtube>
			</social>
			<citations>
				<citation>
					<source>http://en.wikipedia.org/wiki/Arnold_Schwarzenegger</source>
					<description>Wikipedia Article</description>
				</citation>
					<citation>
						<source>http://www.imdb.com/name/nm0000216/bio</source>
						<description>IMDB</description>
				</citation>
			</citations>
			<!--<organization-refs>southern_cali_wildfires_fund</organization-refs>
			<crisis-refs>california_wildfires</crisis-refs>-->
		</person>
			"""
		tree = ET.fromstring(s)
		data = {}
		p = x.createPersonModel(tree)
		self.assertEquals(p.city, "Los Angeles")
		
	def test_createOrganizationModel_1(self):
		x = importXML()
		s = """
			<organization id="unicef">
			<name>UNICEF</name>
			<alternate-names>United Nations Children's Fund</alternate-names>
			<kind>Emergency Fund</kind>
			<description>UNICEF was created by the United Nations General Assembly on December 11, 1946, to provide emergency food and healthcare to children in countries that had been devastated by World War II. In 1954, UNICEF became a permanent part of the United Nations System and its name was shortened from the original United Nations International Children's Emergency Fund but it has continued to be known by the popular acronym based on this old name.</description>
			<location>
				<city>New York City</city> 
				<state>NY</state>
				<country>USA</country>
			</location>
			<images>
				<image>
					<source>http://www.un.org/News/dh/photos/large/2011/November/10-11-2011thailand.jpg</source>
					<description>UNICEF ramps up efforts to help flood victims in Thailand</description>
				</image>
				<image>
					<source>http://adsoftheworld.com/files/images/unicefDirtyWater.jpg</source>
					<description>Unicef / Tap Project: Dirty water</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/1/198df6b6865f068b809ec044354eec89/l.png</source>
					<description>For every dollar raised, a child will have clean drinking water for 40 days</description>
				</image>
				<image>
					<source>http://a1.ec-images.myspacecdn.com/images01/122/ccc294ab2aea06c3ad2827dccdcf6ba1/l.jpg</source>
					<description>Laurence Fishburne supporting UNICEF</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/101/7fa4d7afcb9310aabb95075bc11fe751/l.jpg</source>
					<description>Lucy Liu supporting UNICEF</description>
				</image>				
			</images>
			<maps>
				<map>
					<source>http://www.unep.org/geo2000/ov-e/ioe6.htm</source>
					<description>Water stress in Africa</description>
				</map>
				<map>
					<source>http://www.guardian.co.uk/news/datablog/interactive/2011/jun/27/data-store-water</source>
					<description>Global water stress - interactive</description>
				</map>				
			</maps>
			<videos>
				<youtube>54wQHjr5npw</youtube>
				<youtube>GrQVrmEUuKM</youtube>
				<youtube>Ug5OdN3QpJI</youtube>
			</videos>
			<social>
				<facebook>uniceftap</facebook>
				<twitter>@UNICEF</twitter>
				<youtube>UNICEFUSA</youtube>
			</social>
			<citations>
				<citation>
					<source>http://www.unicef.org/about/who/index_introduction.html</source>
					<description>UNICEF Description</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/Unicef</source>
					<description>Wikipedia Article for UNICEF</description>
				</citation>
				<citation>
					<source>http://www.wateraid.org/international/what_we_do/statistics/default.asp</source>
					<description>783 million people in the world do not have access to safe water. This is roughly one in ten of the world's population.</description>
				</citation>	
			</citations>
			<address>125 Maiden Lane New York, NY 10038</address>
			<email>monthlygiving@unicefusa.org</email>
			<phone>800 367-5437</phone>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<crisis-refs>world_wide_water_shortage</crisis-refs>-->
		</organization>
			"""
		tree = ET.fromstring(s)
		data = {}
		o = x.createPersonModel(tree)
		self.assertEquals(o.name, "UNICEF")
		
	def test_createOrganizationModel_2(self):
		x = importXML()
		s = """
			<organization id="unicef">
			<name>UNICEF</name>
			<alternate-names>United Nations Children's Fund</alternate-names>
			<kind>Emergency Fund</kind>
			<description>UNICEF was created by the United Nations General Assembly on December 11, 1946, to provide emergency food and healthcare to children in countries that had been devastated by World War II. In 1954, UNICEF became a permanent part of the United Nations System and its name was shortened from the original United Nations International Children's Emergency Fund but it has continued to be known by the popular acronym based on this old name.</description>
			<location>
				<city>New York City</city> 
				<state>NY</state>
				<country>USA</country>
			</location>
			<images>
				<image>
					<source>http://www.un.org/News/dh/photos/large/2011/November/10-11-2011thailand.jpg</source>
					<description>UNICEF ramps up efforts to help flood victims in Thailand</description>
				</image>
				<image>
					<source>http://adsoftheworld.com/files/images/unicefDirtyWater.jpg</source>
					<description>Unicef / Tap Project: Dirty water</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/1/198df6b6865f068b809ec044354eec89/l.png</source>
					<description>For every dollar raised, a child will have clean drinking water for 40 days</description>
				</image>
				<image>
					<source>http://a1.ec-images.myspacecdn.com/images01/122/ccc294ab2aea06c3ad2827dccdcf6ba1/l.jpg</source>
					<description>Laurence Fishburne supporting UNICEF</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/101/7fa4d7afcb9310aabb95075bc11fe751/l.jpg</source>
					<description>Lucy Liu supporting UNICEF</description>
				</image>				
			</images>
			<maps>
				<map>
					<source>http://www.unep.org/geo2000/ov-e/ioe6.htm</source>
					<description>Water stress in Africa</description>
				</map>
				<map>
					<source>http://www.guardian.co.uk/news/datablog/interactive/2011/jun/27/data-store-water</source>
					<description>Global water stress - interactive</description>
				</map>				
			</maps>
			<videos>
				<youtube>54wQHjr5npw</youtube>
				<youtube>GrQVrmEUuKM</youtube>
				<youtube>Ug5OdN3QpJI</youtube>
			</videos>
			<social>
				<facebook>uniceftap</facebook>
				<twitter>@UNICEF</twitter>
				<youtube>UNICEFUSA</youtube>
			</social>
			<citations>
				<citation>
					<source>http://www.unicef.org/about/who/index_introduction.html</source>
					<description>UNICEF Description</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/Unicef</source>
					<description>Wikipedia Article for UNICEF</description>
				</citation>
				<citation>
					<source>http://www.wateraid.org/international/what_we_do/statistics/default.asp</source>
					<description>783 million people in the world do not have access to safe water. This is roughly one in ten of the world's population.</description>
				</citation>	
			</citations>
			<address>125 Maiden Lane New York, NY 10038</address>
			<email>monthlygiving@unicefusa.org</email>
			<phone>800 367-5437</phone>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<crisis-refs>world_wide_water_shortage</crisis-refs>-->
		</organization>
			"""
		tree = ET.fromstring(s)
		data = {}
		o = x.createPersonModel(tree)
		self.assertEquals(o.name, "UNICEF")

	
		
	def test_createModels_1(self):
		x = importXML()
		s = """
			<world-crises>
			<crises>
			<crisis id="thai_flood">
			<name>2011 Thailand floods</name>
			<kind>Natural Disaster</kind>
			<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
			<location>
				<country>Thailand and Cambodia</country>		
			</location>
			<maps>
				<map>
					<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
					<description>Thai Flood Map</description>
				</map>
				<map>
					<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
					<description>Thai Flood Map</description>
				</map>			
			</maps>
			<videos>
				<youtube>tWXnIXvHhCs</youtube>
			</videos>
			<social>
				<facebook>ThaiFloodEng</facebook>
				<twitter>@thaifloodeng</twitter>
			</social>
			<citations>
				<citation>
					<source>http://www.nytimes.com/</source>
					<description>New York Times</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
					<description>Wikipedia article for this object</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</citation>
				<citation>
					<source>http://www.bbc.co.uk/news/world/</source>
					<description>BBC News</description>
				</citation>
				<citation>
					<source>http://www.theatlantic.com/</source>
					<description>The Atlantic</description>
				</citation>
				<citation>
					<source>http://www.cnn.com/</source>
					<description>CNN</description>
				</citation>
				<citation>
					<source>http://www.huffingtonpost.com/</source>
					<description>Huffington Post</description>
				</citation>
				<citation>
					<source>http://globalvoicesonline.org/</source>
					<description>Global Voices Online</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.washingtonpost.com/</source>
					<description>Washingtonpost.com</description>
				</citation>
				<citation>
					<source>http://www.guardiannews.com/</source>
					<description>Guardian UK</description>
				</citation>
				<citation>
					<source>http://www.unicef.org/</source>
					<description>UNICEF</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
					<description>Worst Flooding in Decades</description>
				</external-link> 
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
					<description>Disastrous Slow Moving Flood</description>
				</external-link>
				<external-link>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</external-link>
				<external-link>
					<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
					<description>Thailand Flooding Death Toll</description>
				</external-link>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
					<description>Reuters Article</description>
				</external-link> 
				<external-link>
					<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
					<description>Bangkok Flooding Waters</description>
				</external-link>
			</external-links>
			<start-date>2011-06-01T12:00:00</start-date>
			<end-date>2012-01-01T12:00:00</end-date>
			<human-impact>
				<deaths>815</deaths>
				<missing>0</missing>
				<injured>720000</injured>
				<displaced>2400000000</displaced>
			</human-impact>
			<economic-impact>45000000000</economic-impact>
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			<person-refs>yingluck_shinawatra</person-refs>
		</crisis>
		</crises>
		<organizations>
		<organization id="unicef">
			<name>UNICEF</name>
			<alternate-names>United Nations Children's Fund</alternate-names>
			<kind>Emergency Fund</kind>
			<description>UNICEF was created by the United Nations General Assembly on December 11, 1946, to provide emergency food and healthcare to children in countries that had been devastated by World War II. In 1954, UNICEF became a permanent part of the United Nations System and its name was shortened from the original United Nations International Children's Emergency Fund but it has continued to be known by the popular acronym based on this old name.</description>
			<location>
				<city>New York City</city> 
				<state>NY</state>
				<country>USA</country>
			</location>
			<images>
				<image>
					<source>http://www.un.org/News/dh/photos/large/2011/November/10-11-2011thailand.jpg</source>
					<description>UNICEF ramps up efforts to help flood victims in Thailand</description>
				</image>
				<image>
					<source>http://adsoftheworld.com/files/images/unicefDirtyWater.jpg</source>
					<description>Unicef / Tap Project: Dirty water</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/1/198df6b6865f068b809ec044354eec89/l.png</source>
					<description>For every dollar raised, a child will have clean drinking water for 40 days</description>
				</image>
				<image>
					<source>http://a1.ec-images.myspacecdn.com/images01/122/ccc294ab2aea06c3ad2827dccdcf6ba1/l.jpg</source>
					<description>Laurence Fishburne supporting UNICEF</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/101/7fa4d7afcb9310aabb95075bc11fe751/l.jpg</source>
					<description>Lucy Liu supporting UNICEF</description>
				</image>				
			</images>
			<maps>
				<map>
					<source>http://www.unep.org/geo2000/ov-e/ioe6.htm</source>
					<description>Water stress in Africa</description>
				</map>
				<map>
					<source>http://www.guardian.co.uk/news/datablog/interactive/2011/jun/27/data-store-water</source>
					<description>Global water stress - interactive</description>
				</map>				
			</maps>
			<videos>
				<youtube>54wQHjr5npw</youtube>
				<youtube>GrQVrmEUuKM</youtube>
				<youtube>Ug5OdN3QpJI</youtube>
			</videos>
			<social>
				<facebook>uniceftap</facebook>
				<twitter>@UNICEF</twitter>
				<youtube>UNICEFUSA</youtube>
			</social>
			<citations>
				<citation>
					<source>http://www.unicef.org/about/who/index_introduction.html</source>
					<description>UNICEF Description</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/Unicef</source>
					<description>Wikipedia Article for UNICEF</description>
				</citation>
				<citation>
					<source>http://www.wateraid.org/international/what_we_do/statistics/default.asp</source>
					<description>783 million people in the world do not have access to safe water. This is roughly one in ten of the world's population.</description>
				</citation>	
			</citations>
			<address>125 Maiden Lane New York, NY 10038</address>
			<email>monthlygiving@unicefusa.org</email>
			<phone>800 367-5437</phone>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<crisis-refs>world_wide_water_shortage</crisis-refs>-->
		</organization>
		</organizations>
		<people>
		<person id="yingluck_shinawatra">
			<name>Yingluck Shinawatra</name>
			<kind>Prime Minister</kind>
			<description>Thai businesswoman and politician, member of the Pheu Thai Party, and the 28th and current Prime Minister of Thailandfollowing the 2011 general election. Yingluck is Thailand's first female Prime Minister and at 44 is the youngest Prime Minister of Thailand in over 60 years.</description>
			<location>
				<city>Bangkok</city>
				<country>Thailand</country>
			</location>
			<images>
				<image>
					<source>http://static.guim.co.uk/sys-images/Politics/Pix/pictures/2012/1/24/1327428661947/Yingluck-Shinawatra-007.jpg</source>
					<description>Yingluck Shinawatra</description>
				</image>
				<image>
					<source>http://www.reuters.com/article/2011/10/28/us-thailand-floods-insight-idUSTRE79R0NK20111028</source>
					<description>With Flood Victims</description>
				</image>
			</images>
			<videos>
				<youtube>wqpBrD5MH70</youtube>
			</videos>
			<social>
				<facebook>Y.Shinawatra</facebook>
				<twitter>@pouyingluck</twitter>
			</social>
			<citations>
				<citation>
					<source>http://en.wikipedia.org/wiki/Yingluck_Shinawatra</source>
					<description>Wikipedia article</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-13723451</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.forbes.com/profile/yingluck-shinawatra/</source>
					<description>Forbes Article</description>
				</external-link>
			</external-links>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<organization-refs>thai_red_cross</organization-refs>-->
		</person>
		</people>
		</world-crises>
			"""
		tree = ET.fromstring(s)
		models = x.createModels(tree)
		self.assertEquals(len(models),3)
		
	def test_createModels_2(self):
		x = importXML()
		s = """
			<world-crises>
			<crises>
			<crisis id="thai_flood">
			<name>2011 Thailand floods</name>
			<kind>Natural Disaster</kind>
			<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
			<location>
				<country>Thailand and Cambodia</country>		
			</location>
			<maps>
				<map>
					<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
					<description>Thai Flood Map</description>
				</map>
				<map>
					<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
					<description>Thai Flood Map</description>
				</map>			
			</maps>
			<videos>
				<youtube>tWXnIXvHhCs</youtube>
			</videos>
			<social>
				<facebook>ThaiFloodEng</facebook>
				<twitter>@thaifloodeng</twitter>
			</social>
			<citations>
				<citation>
					<source>http://www.nytimes.com/</source>
					<description>New York Times</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
					<description>Wikipedia article for this object</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</citation>
				<citation>
					<source>http://www.bbc.co.uk/news/world/</source>
					<description>BBC News</description>
				</citation>
				<citation>
					<source>http://www.theatlantic.com/</source>
					<description>The Atlantic</description>
				</citation>
				<citation>
					<source>http://www.cnn.com/</source>
					<description>CNN</description>
				</citation>
				<citation>
					<source>http://www.huffingtonpost.com/</source>
					<description>Huffington Post</description>
				</citation>
				<citation>
					<source>http://globalvoicesonline.org/</source>
					<description>Global Voices Online</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.washingtonpost.com/</source>
					<description>Washingtonpost.com</description>
				</citation>
				<citation>
					<source>http://www.guardiannews.com/</source>
					<description>Guardian UK</description>
				</citation>
				<citation>
					<source>http://www.unicef.org/</source>
					<description>UNICEF</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
					<description>Worst Flooding in Decades</description>
				</external-link> 
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
					<description>Disastrous Slow Moving Flood</description>
				</external-link>
				<external-link>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</external-link>
				<external-link>
					<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
					<description>Thailand Flooding Death Toll</description>
				</external-link>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
					<description>Reuters Article</description>
				</external-link> 
				<external-link>
					<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
					<description>Bangkok Flooding Waters</description>
				</external-link>
			</external-links>
			<start-date>2011-06-01T12:00:00</start-date>
			<end-date>2012-01-01T12:00:00</end-date>
			<human-impact>
				<deaths>815</deaths>
				<missing>0</missing>
				<injured>720000</injured>
				<displaced>2400000000</displaced>
			</human-impact>
			<economic-impact>45000000000</economic-impact>
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			<person-refs>yingluck_shinawatra</person-refs>
		</crisis>
		</crises>
		<organizations>
		<organization id="unicef">
			<name>UNICEF</name>
			<alternate-names>United Nations Children's Fund</alternate-names>
			<kind>Emergency Fund</kind>
			<description>UNICEF was created by the United Nations General Assembly on December 11, 1946, to provide emergency food and healthcare to children in countries that had been devastated by World War II. In 1954, UNICEF became a permanent part of the United Nations System and its name was shortened from the original United Nations International Children's Emergency Fund but it has continued to be known by the popular acronym based on this old name.</description>
			<location>
				<city>New York City</city> 
				<state>NY</state>
				<country>USA</country>
			</location>
			<images>
				<image>
					<source>http://www.un.org/News/dh/photos/large/2011/November/10-11-2011thailand.jpg</source>
					<description>UNICEF ramps up efforts to help flood victims in Thailand</description>
				</image>
				<image>
					<source>http://adsoftheworld.com/files/images/unicefDirtyWater.jpg</source>
					<description>Unicef / Tap Project: Dirty water</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/1/198df6b6865f068b809ec044354eec89/l.png</source>
					<description>For every dollar raised, a child will have clean drinking water for 40 days</description>
				</image>
				<image>
					<source>http://a1.ec-images.myspacecdn.com/images01/122/ccc294ab2aea06c3ad2827dccdcf6ba1/l.jpg</source>
					<description>Laurence Fishburne supporting UNICEF</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/101/7fa4d7afcb9310aabb95075bc11fe751/l.jpg</source>
					<description>Lucy Liu supporting UNICEF</description>
				</image>				
			</images>
			<maps>
				<map>
					<source>http://www.unep.org/geo2000/ov-e/ioe6.htm</source>
					<description>Water stress in Africa</description>
				</map>
				<map>
					<source>http://www.guardian.co.uk/news/datablog/interactive/2011/jun/27/data-store-water</source>
					<description>Global water stress - interactive</description>
				</map>				
			</maps>
			<videos>
				<youtube>54wQHjr5npw</youtube>
				<youtube>GrQVrmEUuKM</youtube>
				<youtube>Ug5OdN3QpJI</youtube>
			</videos>
			<social>
				<facebook>uniceftap</facebook>
				<twitter>@UNICEF</twitter>
				<youtube>UNICEFUSA</youtube>
			</social>
			<citations>
				<citation>
					<source>http://www.unicef.org/about/who/index_introduction.html</source>
					<description>UNICEF Description</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/Unicef</source>
					<description>Wikipedia Article for UNICEF</description>
				</citation>
				<citation>
					<source>http://www.wateraid.org/international/what_we_do/statistics/default.asp</source>
					<description>783 million people in the world do not have access to safe water. This is roughly one in ten of the world's population.</description>
				</citation>	
			</citations>
			<address>125 Maiden Lane New York, NY 10038</address>
			<email>monthlygiving@unicefusa.org</email>
			<phone>800 367-5437</phone>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<crisis-refs>world_wide_water_shortage</crisis-refs>-->
		</organization>
		</organizations>
		<people>
		<person id="yingluck_shinawatra">
			<name>Yingluck Shinawatra</name>
			<kind>Prime Minister</kind>
			<description>Thai businesswoman and politician, member of the Pheu Thai Party, and the 28th and current Prime Minister of Thailandfollowing the 2011 general election. Yingluck is Thailand's first female Prime Minister and at 44 is the youngest Prime Minister of Thailand in over 60 years.</description>
			<location>
				<city>Bangkok</city>
				<country>Thailand</country>
			</location>
			<images>
				<image>
					<source>http://static.guim.co.uk/sys-images/Politics/Pix/pictures/2012/1/24/1327428661947/Yingluck-Shinawatra-007.jpg</source>
					<description>Yingluck Shinawatra</description>
				</image>
				<image>
					<source>http://www.reuters.com/article/2011/10/28/us-thailand-floods-insight-idUSTRE79R0NK20111028</source>
					<description>With Flood Victims</description>
				</image>
			</images>
			<videos>
				<youtube>wqpBrD5MH70</youtube>
			</videos>
			<social>
				<facebook>Y.Shinawatra</facebook>
				<twitter>@pouyingluck</twitter>
			</social>
			<citations>
				<citation>
					<source>http://en.wikipedia.org/wiki/Yingluck_Shinawatra</source>
					<description>Wikipedia article</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-13723451</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.forbes.com/profile/yingluck-shinawatra/</source>
					<description>Forbes Article</description>
				</external-link>
			</external-links>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<organization-refs>thai_red_cross</organization-refs>-->
		</person>
		</people>
		</world-crises>
			"""
		tree = ET.fromstring(s)
		models = x.createModels(tree)
		self.assert_(models != None)
		
	def test_createModels_3(self):
		x = importXML()
		s = """
			<world-crises>
			<crises>
			<crisis id="thai_flood">
			<name>2011 Thailand floods</name>
			<kind>Natural Disaster</kind>
			<description>Severe flooding occurred during the 2011 monsoon season in Thailand. Beginning at the end of July triggered by the landfall of Tropical Storm Nock-ten, flooding soon spread through the provinces of Northern, Northeastern and Central Thailand along the Mekong and Chao Phraya river basins</description>
			<location>
				<country>Thailand and Cambodia</country>		
			</location>
			<maps>
				<map>
					<source>http://globalvoicesonline.org/wp-content/uploads/2011/10/thai_flood_map.png</source>
					<description>Thai Flood Map</description>
				</map>
				<map>
					<source>http://www.mapsofworld.com/thailand/maps/thailand-flood-map.jpg</source>
					<description>Thai Flood Map</description>
				</map>			
			</maps>
			<videos>
				<youtube>tWXnIXvHhCs</youtube>
			</videos>
			<social>
				<facebook>ThaiFloodEng</facebook>
				<twitter>@thaifloodeng</twitter>
			</social>
			<citations>
				<citation>
					<source>http://www.nytimes.com/</source>
					<description>New York Times</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/2011_Thailand_floods</source>
					<description>Wikipedia article for this object</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</citation>
				<citation>
					<source>http://www.bbc.co.uk/news/world/</source>
					<description>BBC News</description>
				</citation>
				<citation>
					<source>http://www.theatlantic.com/</source>
					<description>The Atlantic</description>
				</citation>
				<citation>
					<source>http://www.cnn.com/</source>
					<description>CNN</description>
				</citation>
				<citation>
					<source>http://www.huffingtonpost.com/</source>
					<description>Huffington Post</description>
				</citation>
				<citation>
					<source>http://globalvoicesonline.org/</source>
					<description>Global Voices Online</description>
				</citation>
				<citation>
					<source>http://www.google.org/crisisresponse/thailand-flood-2011.html</source>
					<description>Google Crisis Response</description>
				</citation>
				<citation>
					<source>http://www.washingtonpost.com/</source>
					<description>Washingtonpost.com</description>
				</citation>
				<citation>
					<source>http://www.guardiannews.com/</source>
					<description>Guardian UK</description>
				</citation>
				<citation>
					<source>http://www.unicef.org/</source>
					<description>UNICEF</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/10/worst-flooding-in-decades-swamps-thailand/100168/</source>
					<description>Worst Flooding in Decades</description>
				</external-link> 
				<external-link>
					<source>http://www.theatlantic.com/infocus/2011/11/thailands-disastrous-slow-moving-flood/100188/</source>
					<description>Disastrous Slow Moving Flood</description>
				</external-link>
				<external-link>
					<source>http://www.boston.com/bigpicture/2011/10/thailand_flood_reaches_bangkok.html</source>
					<description>Thailand Flood Reaches Bangkok</description>
				</external-link>
				<external-link>
					<source>http://www.huffingtonpost.com/2011/11/20/thailand-flooding-2011-death-toll_n_1103930.html#s486779</source>
					<description>Thailand Flooding Death Toll</description>
				</external-link>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-15491338</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.reuters.com/article/2011/10/26/us-thailand-floods-idUSTRE79K2XG20111026</source>
					<description>Reuters Article</description>
				</external-link> 
				<external-link>
					<source>http://www.guardian.co.uk/world/gallery/2011/oct/25/bangkok-flooding-waters-in-pictures#/?picture=380926679&amp;index=7</source>
					<description>Bangkok Flooding Waters</description>
				</external-link>
			</external-links>
			<start-date>2011-06-01T12:00:00</start-date>
			<end-date>2012-01-01T12:00:00</end-date>
			<human-impact>
				<deaths>815</deaths>
				<missing>0</missing>
				<injured>720000</injured>
				<displaced>2400000000</displaced>
			</human-impact>
			<economic-impact>45000000000</economic-impact>
			<resources-needed>
				<resource>Cleanup teams</resource>
				<resource>flood mitigation projects</resource>
				<resource>survival packs with food, clean water, tissues, candles, lighters, and basic medication</resource>
				<resource>life vests</resource>
				<resource>pvc pipe for rafts</resource>
				<resource>industrial water pumps</resource>
				<resource>shelter</resource>
				<resource>ways to restore damaged infrastructure</resource>
				<resource>at least 1.5 million sandbags</resource>
				<resource>mosquito nets</resource>
			</resources-needed>
			<ways-to-help>
				<way>donate to Thai Red Cross</way>
			</ways-to-help>
			<person-refs>yingluck_shinawatra</person-refs>
		</crisis>
		</crises>
		<organizations>
		<organization id="unicef">
			<name>UNICEF</name>
			<alternate-names>United Nations Children's Fund</alternate-names>
			<kind>Emergency Fund</kind>
			<description>UNICEF was created by the United Nations General Assembly on December 11, 1946, to provide emergency food and healthcare to children in countries that had been devastated by World War II. In 1954, UNICEF became a permanent part of the United Nations System and its name was shortened from the original United Nations International Children's Emergency Fund but it has continued to be known by the popular acronym based on this old name.</description>
			<location>
				<city>New York City</city> 
				<state>NY</state>
				<country>USA</country>
			</location>
			<images>
				<image>
					<source>http://www.un.org/News/dh/photos/large/2011/November/10-11-2011thailand.jpg</source>
					<description>UNICEF ramps up efforts to help flood victims in Thailand</description>
				</image>
				<image>
					<source>http://adsoftheworld.com/files/images/unicefDirtyWater.jpg</source>
					<description>Unicef / Tap Project: Dirty water</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/1/198df6b6865f068b809ec044354eec89/l.png</source>
					<description>For every dollar raised, a child will have clean drinking water for 40 days</description>
				</image>
				<image>
					<source>http://a1.ec-images.myspacecdn.com/images01/122/ccc294ab2aea06c3ad2827dccdcf6ba1/l.jpg</source>
					<description>Laurence Fishburne supporting UNICEF</description>
				</image>
				<image>
					<source>http://a2.ec-images.myspacecdn.com/images01/101/7fa4d7afcb9310aabb95075bc11fe751/l.jpg</source>
					<description>Lucy Liu supporting UNICEF</description>
				</image>				
			</images>
			<maps>
				<map>
					<source>http://www.unep.org/geo2000/ov-e/ioe6.htm</source>
					<description>Water stress in Africa</description>
				</map>
				<map>
					<source>http://www.guardian.co.uk/news/datablog/interactive/2011/jun/27/data-store-water</source>
					<description>Global water stress - interactive</description>
				</map>				
			</maps>
			<videos>
				<youtube>54wQHjr5npw</youtube>
				<youtube>GrQVrmEUuKM</youtube>
				<youtube>Ug5OdN3QpJI</youtube>
			</videos>
			<social>
				<facebook>uniceftap</facebook>
				<twitter>@UNICEF</twitter>
				<youtube>UNICEFUSA</youtube>
			</social>
			<citations>
				<citation>
					<source>http://www.unicef.org/about/who/index_introduction.html</source>
					<description>UNICEF Description</description>
				</citation>
				<citation>
					<source>http://en.wikipedia.org/wiki/Unicef</source>
					<description>Wikipedia Article for UNICEF</description>
				</citation>
				<citation>
					<source>http://www.wateraid.org/international/what_we_do/statistics/default.asp</source>
					<description>783 million people in the world do not have access to safe water. This is roughly one in ten of the world's population.</description>
				</citation>	
			</citations>
			<address>125 Maiden Lane New York, NY 10038</address>
			<email>monthlygiving@unicefusa.org</email>
			<phone>800 367-5437</phone>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<crisis-refs>world_wide_water_shortage</crisis-refs>-->
		</organization>
		</organizations>
		<people>
		<person id="yingluck_shinawatra">
			<name>Yingluck Shinawatra</name>
			<kind>Prime Minister</kind>
			<description>Thai businesswoman and politician, member of the Pheu Thai Party, and the 28th and current Prime Minister of Thailandfollowing the 2011 general election. Yingluck is Thailand's first female Prime Minister and at 44 is the youngest Prime Minister of Thailand in over 60 years.</description>
			<location>
				<city>Bangkok</city>
				<country>Thailand</country>
			</location>
			<images>
				<image>
					<source>http://static.guim.co.uk/sys-images/Politics/Pix/pictures/2012/1/24/1327428661947/Yingluck-Shinawatra-007.jpg</source>
					<description>Yingluck Shinawatra</description>
				</image>
				<image>
					<source>http://www.reuters.com/article/2011/10/28/us-thailand-floods-insight-idUSTRE79R0NK20111028</source>
					<description>With Flood Victims</description>
				</image>
			</images>
			<videos>
				<youtube>wqpBrD5MH70</youtube>
			</videos>
			<social>
				<facebook>Y.Shinawatra</facebook>
				<twitter>@pouyingluck</twitter>
			</social>
			<citations>
				<citation>
					<source>http://en.wikipedia.org/wiki/Yingluck_Shinawatra</source>
					<description>Wikipedia article</description>
				</citation>
			</citations>
			<external-links>
				<external-link>
					<source>http://www.bbc.co.uk/news/world-asia-pacific-13723451</source>
					<description>BBC Article</description>
				</external-link>
				<external-link>
					<source>http://www.forbes.com/profile/yingluck-shinawatra/</source>
					<description>Forbes Article</description>
				</external-link>
			</external-links>
			<crisis-refs>thai_flood</crisis-refs>
			<!--<organization-refs>thai_red_cross</organization-refs>-->
		</person>
		</people>
		</world-crises>
			"""
		tree = ET.fromstring(s)
		models = x.createModels(tree)
		self.assert_(models[0] != None)
		self.assert_(models[1] != None)
		self.assert_(models[2] != None)
		
	
	"""
getcrisisidrefs
create personmodel
createmodels
	"""
