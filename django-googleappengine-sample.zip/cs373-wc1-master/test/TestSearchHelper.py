#!/usr/bin/env python

# -------
# imports
# -------

import sys
import os

sys.path.append("./html")
import StringIO
import unittest
from searchhelper import *
from importXML import importXML
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestCrisisModel (unittest.TestCase) :
	"""
	Test the GAE model of the Crises
	"""

	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
		
	def tearDown(self):
		self.testbed.deactivate()
	
	def test_populateSearchRecords_1 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		t = []
		self.assertTrue((db.GqlQuery("SELECT * FROM People where name='Matt Damon'").get()) != None)
		t.append(('name', db.GqlQuery("SELECT * FROM People where name='Matt Damon'").get()))
		template = {}
		result = populateSearchByRecords('Matt', t, template)
		self.assertEquals(template, {'search': [{'text': ('Name', '<strong style="background-color:#FFFF00;">Matt</strong> Damon'), 'link': '/people/matt_damon.html', 'name': 'Matt Damon'}]})
	
	def test_populateSearchRecords_2 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		t = []
		self.assertTrue((db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'").get()) != None)
		t.append(('description', db.GqlQuery("SELECT * FROM Crisis where name='2011 Thailand floods'").get()))
		template = {}
		result = populateSearchByRecords('Tropical Storm', t, template)
		self.assertEquals(template, {'search': [{'text': ('Description', u'... triggered by the landfall of <strong style="background-color:#FFFF00;">Tropical Storm</strong> Nock-ten, flooding soon spread through the p...'), 'link': u'/crises/thai_flood.html', 'name': u'2011 Thailand floods'}]})

	def test_populateSearchRecords_3 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		t = []
		self.assertTrue((db.GqlQuery("SELECT * FROM Organization where name='Water.org'").get()) != None)
		t.append(('description', db.GqlQuery("SELECT * FROM Organization where name='Water.org'").get()))
		template = {}
		result = populateSearchByRecords('Matt', t, template)
		self.assertEquals(template, {'search': [{'text': ('Description', u'Co-founded by <strong style="background-color:#FFFF00;">Matt</strong> Damon and Gary White, Water.org is a nonprofit organization that has t...'), 'link': u'/organizations/water_org.html', 'name': u'Water.org'}]})

	def test_populateSearchRecords_4 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		t = []
		self.assertTrue((db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'").get()) != None)
		t.append(('ways_to_help', db.GqlQuery("SELECT * FROM Crisis where name='Huricane Andrew'").get()))
		template = {}
		result = populateSearchByRecords('Donate', t, template)
		self.assertEquals(template, {'search': [{'text': ('Ways To Help', u'<ul><li><strong style="background-color:#FFFF00;">Donate</strong> food and water through the same</li></ul>'), 'link': u'/crises/hurricane_andrew.html', 'name': u'Huricane Andrew'}]})

	def test_populateSearchKeys_1 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		keys = ['matt_damon']
		exp = []
		for key in keys:
			exp.append((db.GqlQuery("SELECT * FROM People where model_id='"+key+"'").get()))
		keys = populateSearchByKeys(keys)
		self.assertEquals(keys, exp)

	def test_populateSearchKeys_2 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		keys = ['matt_damon', 'yingluck_shinawatra']
		exp = []
		for key in keys:
			exp.append((db.GqlQuery("SELECT * FROM People where model_id='"+key+"'").get()))
		keys = populateSearchByKeys(keys)
		self.assertEquals(keys, exp)

	def test_populateSearchKeys_3 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		keys = ['california_wildfires', 'thai_flood', 'hurricane_andrew']
		exp = []
		for key in keys:
			exp.append((db.GqlQuery("SELECT * FROM Crisis where model_id='"+key+"'").get()))
		keys = populateSearchByKeys(keys)
		self.assertEquals(keys, exp)
	
	def test_formatKeys_1 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		keys = [('name', 'california_wildfires')]
		template_values = {}
		formatKeys("Cal", keys, template_values)
		self.assertEquals(template_values, {'search': [{'text': ('Name', u'...2010 <strong style="background-color:#FFFF00;">Cal</strong>ifornia Wildfires...'), 'link': u'/crises/california_wildfires.html', 'name': u'2010 California Wildfires'}]})

	def test_formatKeys_2 (self) :
		x = importXML()
		x.importDocuments("world-crises.xml")
		keys = [(u'name', u'matt_damon'), (u'description', u'water_org'), (u'description', u'matt_damon')]
		template_values = {}
		formatKeys("Matt", keys, template_values)
		self.assertEquals(template_values, {'search': [{'text': (u'Name', u'...<strong style="background-color:#FFFF00;">Matt</strong> Damon...'), 'link': u'/people/matt_damon.html', 'name': u'Matt Damon'}, {'text': (u'Description', u'...Co-founded by <strong style="background-color:#FFFF00;">Matt</strong> Damon and Gary White, Water.org is a nonprofit organization that has transformed hundreds of communities in Africa, South...'), 'link': u'/organizations/water_org.html', 'name': u'Water.org'}, {'text': (u'Description', u'...<strong style="background-color:#FFFF00;">Matt</strong>hew Paige Damon was born on October 8, 1970, in Boston Massachusetts to Kent Damon, a stockbroker, Realtor and tax preparer, and Nancy C...'), 'link': u'/people/matt_damon.html', 'name': u'Matt Damon'}]})