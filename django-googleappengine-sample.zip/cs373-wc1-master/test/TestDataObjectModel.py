#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os
sys.path.append("/..")
sys.path.append("./Model")
import StringIO
import unittest
from Data import Data
from Crisis import Crisis
from Link import Link
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestDataModel (unittest.TestCase) :
	"""
	Test the GAE model for raw Data
	"""

	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
		
	def tearDown(self):
		self.testbed.deactivate()
	
	def test_Data_1(self) :
		da1 = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		key = da1.put()
		da2 = db.get(key)
		self.assertEquals(da1, da2)
	
	def test_Data_2(self) :
		da1 = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		key = da1.put()
		rows = db.GqlQuery("SELECT * FROM Data")
		da2 = rows[0]
		self.assertEquals(da1, da2)
	
	def test_init_1(self) :
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da[0], ("1", "1", "1"))
	
	def test_init_2(self) :
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da[1], ("2", "2", "2"))
		
	def test_init_3(self) :
		da = Data()
		self.assertEquals(len(da), 0)
	
	def test_insert_tuple_1(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da.insert_tuple(0, ("3", "3", "3"))
		self.assertEquals(da[0], ("3", "3", "3"))
		
	def test_insert_tuple_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da.insert_tuple(1, ("3", "3", "3"))
		self.assertEquals(da[1], ("3", "3", "3"))
		
	def test_insert_tuple_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		test = 1
		try:
			da.insert_tuple(3, ("3", "3", "3"))
			test = 0
		except AssertionError:
			pass
		self.assertTrue(test)
		
	def test_get_tuple_1(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da.get_tuple(0), ("1", "1", "1"))
		
	def test_get_tuple_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da.get_tuple(1), ("2", "2", "2"))
		
	def test_get_tuple_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		test = 1
		try:
			self.assertEquals(da.get_tuple(3), ("1", "1", "1"))
			test = 0
		except AssertionError:
			pass
		self.assertTrue(test)
		
	def test_remove_tuple_1(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da.remove_tuple(0)
		self.assertEquals(da[0], ("2", "2", "2"))
		
	def test_remove_tuple_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da.remove_tuple(1)
		self.assertEquals(da[0], ("1", "1", "1"))
		self.assertEquals(len(da), 1)
		
	def test_remove_tuple_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		test = 1
		try:
			da.remove_tuple(2)
			test = 0
		except AssertionError:
			pass
		self.assertTrue(test)
		
	def test_iter_1(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		it = iter(da)
		self.assertEquals(it.next(), ("1", "1", "1"))
		
	def test_iter_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		it = iter(da)
		it.next()
		self.assertEquals(it.next(), ("2", "2", "2"))
		
	def test_iter_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		it = iter(da)
		test = 1
		try:
			it.next()
			it.next()
			it.next()
			test = 0
		except StopIteration:
			pass
		self.assertTrue(test)
		
	def test_len_1(self):
		da = Data(tuples = [("1", "1", "1")])
		self.assertEquals(len(da), 1)
		
	def test_len_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(len(da), 2)
		
	def test_len_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da.remove_tuple(0)
		self.assertEquals(len(da), 1)
		
	def test_eq_1(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da, [("1", "1", "1"), ("2", "2", "2")])
		
	def test_eq_2(self):
		da = Data()
		self.assertEquals(da, [])
		
	def test_eq_3(self):
		da1 = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da2 = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da1, da2)
	
	def test_getitem_1(self):
		da = Data()
		da.append_tuple(("1", "1", "1"))
		self.assertEquals(da[0], ("1", "1", "1"))
		
	def test_getitem_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertEquals(da[1], ("2", "2", "2"))
		
	def test_getitem_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		test = 1
		try:
			da[3]
			test = 0
		except AssertionError:
			pass
		self.assertTrue(test)
	
	def test_setitem_1(self):
		da = Data()
		da.append_tuple(("1", "1", "1"))
		da[0] = ("2", "2", "2")
		self.assertEquals(da[0], ("2", "2", "2"))
		
	def test_setitem_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		da[1] = ("3", "3", "3")
		self.assertEquals(da[1], ("3", "3", "3"))
		
	def test_setitem_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		test = 1
		try:
			da[3] = ("3", "3", "3")
			test = 0
		except AssertionError:
			pass
		self.assertTrue(test)
		
	def test_contains_1(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertTrue(da.contains(("2", "2", "2")))
		
	def test_contains_2(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertTrue(not da.contains(("3", "3", "3")))
		
	def test_contains_3(self):
		da = Data(tuples = [("1", "1", "1"), ("2", "2", "2")])
		self.assertTrue(da.contains(("1", "1", "1")))
	
	