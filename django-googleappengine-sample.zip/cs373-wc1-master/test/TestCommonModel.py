#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os

sys.path.append("./Model")
import StringIO
import unittest
from Common import Common
from Link import Link
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestCrisisModel (unittest.TestCase) :
	"""
	Test the GAE model of the Crises
	"""
	
	def setUp(self):
		self.name = "Test Name"
		self.model_kind = "Celeb"
		self.description = "Stupid but popular"
		self.city = "Austin"
		self.country = "USA"
		self.model_id = "dumb_celeb"
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
		
	def tearDown(self):
		self.testbed.deactivate()
	
	def getBasicModel(self) :
		c = Common(name = self.name,
				   model_kind = self.model_kind,
				   description = self.description,
				   city = self.city,
				   country = self.country,
				   model_id = self.model_id
				   )
		return c
	
	def test_common_getField_1 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.getField('name'), "Test Name")

	def test_common_getField_2 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.getField('model_kind'), "Celeb")

	def test_common_getField_3 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.getField('city'), "Austin")

	def test_Common_capitalize_1 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.capitalize('test'), 'Test')

	def test_Common_capitalize_2 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.capitalize('test_underscore'), 'Test Underscore')

	def test_Common_capitalize_3 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.capitalize('Test_Already_Capitaized'), 'Test Already Capitaized')

	def test_Common_shorten_text_1 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.highlightString('Short enough.', 'Short'), '<strong style="background-color:#FFFF00;">Short</strong> enough.')

	def test_Common_shorten_text_2 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.highlightString('Not Short enough, but the word is included in the first part of the text. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content.', 'Short'), 'Not <strong style="background-color:#FFFF00;">Short</strong> enough, but the word is included in the first part of the text. Added Content. ...')

	def test_Common_shorten_text_3 (self) :
		c = self.getBasicModel()
		self.assertEquals(c.highlightString('Short enough. Not Short enough, but the word is included in the first part of the text. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Something. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content.', 'Something'), '...Added Content. Added Content. <strong style="background-color:#FFFF00;">Something</strong>. Added Content. Added Content. Added Content. Add...')

	def test_Common_shorten_list_1 (self) :
		c = self.getBasicModel()
		c.ways_to_help = ['give money', 'be nice', 'keep away mean people']
		self.assertEquals(c.highlightList(c.ways_to_help, 'nice'), '<ul><li>give money</li><li>be <strong style="background-color:#FFFF00;">nice</strong></li><li>keep away mean people</li></ul>')
	
	def test_Common_shorten_list_2 (self) :
		c = self.getBasicModel()
		c.ways_to_help = ['give money', 'be nice', 'keep away mean people', 'something here']
		self.assertEquals(c.highlightList(c.ways_to_help, 'give'), '<ul><li><strong style="background-color:#FFFF00;">give</strong> money</li><li>be nice</li><li>keep away mean people</li></ul>')
	
	def test_Common_shorten_list_3 (self) :
		c = self.getBasicModel()
		c.ways_to_help = ['something here', 'give money', 'be nice', 'keep away mean people']
		self.assertEquals(c.highlightList(c.ways_to_help, 'people'), '<ul><li>give money</li><li>be nice</li><li>keep away mean <strong style="background-color:#FFFF00;">people</strong></li></ul>')
						  
	def test_Common_getHighlight_1 (self) :
		c = self.getBasicModel()
		c.name = 'Matt Damon'
		self.assertEquals(c.getHighlight('name', 'Matt'), ('Name', '<strong style="background-color:#FFFF00;">Matt</strong> Damon'))

	def test_Common_getHighlight_2 (self) :
		c = self.getBasicModel()
		c.description = 'Not Short enough, but the word is included in the first part of the text. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content.'
		self.assertEquals(c.getHighlight('description', 'Short'), ('Description', 'Not <strong style="background-color:#FFFF00;">Short</strong> enough, but the word is included in the first part of the text. Added Content. ...'))

	def test_Common_getHighlight_3 (self) :
		c = self.getBasicModel()
		c.description = 'Short enough. Not Short enough, but the word is included in the first part of the text. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Something. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content.'
		self.assertEquals(c.getHighlight('description', 'Something'), ('Description', '...Added Content. Added Content. <strong style="background-color:#FFFF00;">Something</strong>. Added Content. Added Content. Added Content. Add...'))

	def test_Common_getHighlight_4 (self) :
		c = self.getBasicModel()
		c.description = 'Short enough. Not Short enough, but the word is included in the first part of the text. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Something. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content.'
		self.assertEquals(c.getHighlight('description', ['Something', 'nothing']), ('Description', '...Added Content. Added Content. <strong style="background-color:#FFFF00;">Something</strong>. Added Content. Added Content. Added Content. Added Content. Added Content. Added Content. Added Con...'))
