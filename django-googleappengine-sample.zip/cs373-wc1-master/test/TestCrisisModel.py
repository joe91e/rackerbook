#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os

sys.path.append("./Model")
import StringIO
import unittest
import Crisis
from Link import Link
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestCrisisModel (unittest.TestCase) :
	"""
	Test the GAE model of the Crises
	"""

	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
		
	def tearDown(self):
		self.testbed.deactivate()
	
	def test_crisis_model_1 (self) :
		name = "test_name"
		alternate_names = "test_alt"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		
		images = []
		link = Link(url = db.Link("http://www.sample.com"),
					description = "A samle URL")
		linkid = link.put()
		images.append(linkid)
		
		maps = [linkid]
		videos_youtube = ["ID"]
		social_youtube = ["ID"]
		citations = [linkid]
		external_links = [linkid]
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		deaths = 25
		missing = 4
		injured = 100
		displaced = 1
		economic_impact = 500
		ways_to_help = ["Love people"]
		organization_refs = ["org1"]
		person_refs = ["person1"]
		model_id = "this_id"
		c = Crisis.Crisis(name = name,
						  alternate_names = alternate_names, 
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  images = images, 
						  maps = maps,
						  videos_youtube = videos_youtube,
						  social_youtube = social_youtube,
						  start_date = start_date,
						  end_date = end_date,
						  deaths = deaths,
						  missing = missing,
						  injured = injured,
						  economic_impact = economic_impact,
						  ways_to_help = ways_to_help,
						  organization_refs = organization_refs,
						  person_refs = person_refs,
						  model_id = model_id
						  )
		# Test against object
		self.assertEquals(c.name, name)
		self.assertEquals(c.alternate_names, alternate_names)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, images)
		self.assertEquals(c.maps, maps)
		self.assertEquals(c.videos_youtube, videos_youtube)
		self.assertEquals(c.social_youtube, social_youtube)
		self.assertEquals(c.start_date, start_date)
		self.assertEquals(c.end_date, end_date)
		self.assertEquals(c.deaths, deaths)
		self.assertEquals(c.missing, missing)
		self.assertEquals(c.injured, injured)
		self.assertEquals(c.economic_impact, economic_impact)
		self.assertEquals(c.ways_to_help, ways_to_help)
		self.assertEquals(c.organization_refs, organization_refs)
		self.assertEquals(c.person_refs, person_refs)
		self.assertEquals(c.model_id, model_id)
		c.put()
		rows = db.GqlQuery("SELECT * FROM Crisis")
		self.assertEquals(rows.get().name, name)
		self.assertEquals(rows.get().alternate_names, alternate_names)
		self.assertEquals(rows.get().model_kind, model_kind)
		self.assertEquals(rows.get().description, description)
		self.assertEquals(rows.get().city, city)
		self.assertEquals(rows.get().images, images)
		self.assertEquals(rows.get().maps, maps)
		self.assertEquals(rows.get().videos_youtube, videos_youtube)
		self.assertEquals(rows.get().social_youtube, social_youtube)
		self.assertEquals(rows.get().start_date, start_date)
		self.assertEquals(rows.get().end_date, end_date)
		self.assertEquals(rows.get().deaths, deaths)
		self.assertEquals(rows.get().missing, missing)
		self.assertEquals(rows.get().injured, injured)
		self.assertEquals(rows.get().economic_impact, economic_impact)
		self.assertEquals(rows.get().ways_to_help, ways_to_help)
		self.assertEquals(rows.get().organization_refs, organization_refs)
		self.assertEquals(rows.get().person_refs, person_refs)
		self.assertEquals(rows.get().model_id, model_id)
		results = rows.fetch(1)
		db.delete(results)
	
	def test_crisis_model_2 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		economic_impact = 500
		model_id = "this_id"
		c = Crisis.Crisis(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  start_date = start_date,
						  end_date = end_date,
						  economic_impact = economic_impact,
						  model_id = model_id
						  )
		self.assertEquals(c.name, name)
		self.assertEquals(c.alternate_names, None)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, [])
		self.assertEquals(c.maps, [])
		self.assertEquals(c.videos_youtube, [])
		self.assertEquals(c.social_youtube, [])
		self.assertEquals(c.start_date, start_date)
		self.assertEquals(c.end_date, end_date)
		self.assertEquals(c.deaths, None)
		self.assertEquals(c.missing, None)
		self.assertEquals(c.injured, None)
		self.assertEquals(c.economic_impact, economic_impact)
		self.assertEquals(c.ways_to_help, [])
		self.assertEquals(c.organization_refs, [])
		self.assertEquals(c.person_refs, [])
		self.assertEquals(c.model_id, model_id)
		c.put()
		rows = db.GqlQuery("SELECT * FROM Crisis")
		self.assertEquals(rows.get().name, name)
		self.assertEquals(rows.get().alternate_names, None)
		self.assertEquals(rows.get().model_kind, model_kind)
		self.assertEquals(rows.get().description, description)
		self.assertEquals(rows.get().city, city)
		self.assertEquals(rows.get().images, [])
		self.assertEquals(rows.get().maps, [])
		self.assertEquals(rows.get().videos_youtube, [])
		self.assertEquals(rows.get().social_youtube, [])
		self.assertEquals(rows.get().start_date, start_date)
		self.assertEquals(rows.get().end_date, end_date)
		self.assertEquals(rows.get().deaths, None)
		self.assertEquals(rows.get().missing, None)
		self.assertEquals(rows.get().injured, None)
		self.assertEquals(rows.get().economic_impact, economic_impact)
		self.assertEquals(rows.get().ways_to_help, [])
		self.assertEquals(rows.get().organization_refs, [])
		self.assertEquals(rows.get().person_refs, [])
		self.assertEquals(rows.get().model_id, model_id)
		results = rows.fetch(1)
		db.delete(results)

	def test_crisis_model_3 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		country = "Somewhere"
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		economic_impact = 500
		model_id = "this_id"
		c1 = Crisis.Crisis(name = name,
						   model_kind = model_kind,
						   description = description,
						   country = country,
						   start_date = start_date,
						   end_date = end_date,
						   economic_impact = economic_impact,
						   model_id = model_id
						   )
		c1.put()
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		country = "Somewhere"
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		economic_impact = 500
		model_id = "this_id"
		c2 = Crisis.Crisis(name = name,
						   model_kind = model_kind,
						   description = description,
						   country = country,
						   start_date = start_date,
						   end_date = end_date,
						   economic_impact = economic_impact,
						   model_id = model_id
						   )
		c2.put()
		rows = db.GqlQuery("SELECT * FROM Crisis")
		self.assertEquals(rows.count(), 2)

	def test_crisis_getLink_1 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		economic_impact = 500
		model_id = "this_id"
		c = Crisis.Crisis(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  start_date = start_date,
						  end_date = end_date,
						  economic_impact = economic_impact,
						  model_id = model_id					  
						  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM Crisis")
		c = rows.get()
		self.assertEquals(c.getLink(), '/crises/this_id.html')

	def test_crisis_getLink_2 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		economic_impact = 500
		model_id = "dead_puppies"
		c = Crisis.Crisis(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  start_date = start_date,
						  end_date = end_date,
						  economic_impact = economic_impact,
						  model_id = model_id					  
						  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM Crisis")
		c = rows.get()
		self.assertEquals(c.getLink(), '/crises/dead_puppies.html')

	def test_crisis_getLink_3 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		start_date = "1-1-2012"
		end_date = "1-1-2012"
		economic_impact = 500
		model_id = "smurf_holocaust"
		c = Crisis.Crisis(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  start_date = start_date,
						  end_date = end_date,
						  economic_impact = economic_impact,
						  model_id = model_id					  
						  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM Crisis")
		c = rows.get()
		self.assertEquals(c.getLink(), '/crises/smurf_holocaust.html')
