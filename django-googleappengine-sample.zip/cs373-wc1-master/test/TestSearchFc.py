#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os
sys.path.append("..")
import SearchFc
from importXML import *
sys.path.append("./Model")
import StringIO
import unittest
from Data import Data
from Crisis import Crisis
from Link import Link
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestDataModel (unittest.TestCase) :
	"""
	Test the GAE model for raw Data
	"""

	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
		x = importXML()
		x.importDocuments("world-crises.xml")
		
	def tearDown(self):
		self.testbed.deactivate()
		
	def test_Search_1(self):
		result = SearchFc.Search("Global")
		self.assertEquals(len(result), 0)
		
	def test_Search_2(self):
		result = SearchFc.Search("Matt Damon")
		self.assertEquals(len(result), 2)
		
	def test_Search_3(self):
		result = SearchFc.Search("UNICEF was created by the United Nations General Assembly")
		# Lots of words should generate lots of results
		self.assertEquals(len(result), 12)
		self.assertEquals(result[0][0], 'description')
		
	def test_Search_4(self):
		result = SearchFc.Search("Nuclear")
		self.assertEquals(len(result), 0)
		
	def test_Search_5(self):
		result = SearchFc.get_substrings(['to', 'the', 'moon', 'alice'])
		self.assertEquals(['to the moon alice', 'the moon alice', 'to the moon', 'moon alice', 'the moon', 'to the', 'alice', 'moon', 'the', 'to'], result)
		
	def test_Search_6(self):
		result = SearchFc.get_substrings(['floppy', 'puppy', 'ears'])
		self.assertEquals(['floppy puppy ears', 'floppy puppy', 'puppy ears', 'floppy', 'puppy', 'ears'], result)
		
	def test_Search_7(self):
		result = SearchFc.get_substrings(['I', 'need', 'to', 'automate', 'this'])
		self.assertEquals(['I need to automate this', 'need to automate this', 'I need to automate', 'need to automate', 'to automate this', 'automate this', 'to automate', 'I need to', 'automate', 'need to', 'I need', 'need', 'this', 'to', 'I'], result)
		
	def test_Search_8(self):
		result = SearchFc.should_append([('to wong foo', 'julie_numar', 7)], 'julie_numar', 8, 'magnificent')
		result = True
		
	def test_Search_9(self):
		result = SearchFc.should_append([('to the moon alice', 'frank', 7)], 'frank', 6, 'pow, boom, straight to the moon')
		result = False
		
	def test_Search_10(self):
		result = SearchFc.should_append([('Queue', 'scrable', 3)], 'julie_numar', 5, 'Qe')
		result = False
		
	
