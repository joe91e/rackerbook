#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
    To test the program:
    % python TestWC1.py >& TestWC1.out
    % chmod ugo+x TestWC1.py
    % TestWC1.py >& TestWC1.out
"""

# -------
# imports
# -------

import sys
import os

sys.path.append("..")

import StringIO
import unittest
import Organization
from Link import Link
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestOrganizationModel (unittest.TestCase) :
	"""
		Test the GAE model of the Crises
	"""
	
	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
	
	def tearDown(self):
		self.testbed.deactivate()
    
	def test_org_model_1 (self) :
		name = "test_name"
		alternate_names = "test_alt"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"

		images = []
		link = Link(url = db.Link("http://www.sample.com"),
					description = "A samle URL")
		linkid = link.put()
		images.append(linkid)
		
		maps = [linkid]
		videos_youtube = ["ID"]
		social_youtube = ["ID"]
		citations = [linkid]
		external_links = [linkid]
		address = "111 Fake Street"
		e_mail = "info@gmail.com"
		phone = "555-555-5555"
		crisis_refs = ["crisis1"]
		person_refs = ["person1"]
		model_id = "this_id"
		c = Organization.Organization(name = name,
									  alternate_names = alternate_names, 
									  model_kind = model_kind,
									  description = description,
									  city = city,
									  images = images, 
									  maps = maps,
									  country = country,
									  videos_youtube = videos_youtube,
									  social_youtube = social_youtube,
									  citations = citations,
									  external_links = external_links,
									  address = address,
									  e_mail = e_mail,
									  phone = phone,
									  crisis_refs = crisis_refs,
									  person_refs = person_refs,
									  model_id = model_id
									  )
		self.assertEquals(c.name, name)
		self.assertEquals(c.alternate_names, alternate_names)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, images)
		self.assertEquals(c.maps, maps)
		self.assertEquals(c.videos_youtube, videos_youtube)
		self.assertEquals(c.social_youtube, social_youtube)
		self.assertEquals(c.address, address)
		self.assertEquals(c.e_mail, e_mail)
		self.assertEquals(c.phone, phone)
		self.assertEquals(c.crisis_refs, crisis_refs)
		self.assertEquals(c.person_refs, person_refs)
		self.assertEquals(c.model_id, model_id)
		c.put()
		rows = db.GqlQuery("SELECT * FROM Organization")
		c = rows.get()
		self.assertEquals(c.name, name)
		self.assertEquals(c.alternate_names, alternate_names)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, images)
		self.assertEquals(c.maps, maps)
		self.assertEquals(c.videos_youtube, videos_youtube)
		self.assertEquals(c.social_youtube, social_youtube)
		self.assertEquals(c.address, address)
		self.assertEquals(c.e_mail, e_mail)
		self.assertEquals(c.phone, phone)
		self.assertEquals(c.crisis_refs, crisis_refs)
		self.assertEquals(c.person_refs, person_refs)
		self.assertEquals(c.model_id, model_id)
    
	def test_org_model_2 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		model_id = "this_id"
		c = Organization.Organization(name = name,
									  model_kind = model_kind,
									  description = description,
									  city = city,
									  country = country,
									  model_id = model_id
									  )
		self.assertEquals(c.name, name)
		self.assertEquals(c.alternate_names, None)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, [])
		self.assertEquals(c.maps, [])
		self.assertEquals(c.videos_youtube, [])
		self.assertEquals(c.social_youtube, [])
		self.assertEquals(c.address, None)
		self.assertEquals(c.e_mail, None)
		self.assertEquals(c.phone, None)
		self.assertEquals(c.crisis_refs, [])
		self.assertEquals(c.person_refs, [])
		self.assertEquals(c.model_id, model_id)
		c.put()
		rows = db.GqlQuery("SELECT * FROM Organization")
		c = rows.get()
		self.assertEquals(c.name, name)
		self.assertEquals(c.alternate_names, None)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, [])
		self.assertEquals(c.maps, [])
		self.assertEquals(c.videos_youtube, [])
		self.assertEquals(c.social_youtube, [])
		self.assertEquals(c.address, None)
		self.assertEquals(c.e_mail, None)
		self.assertEquals(c.phone, None)
		self.assertEquals(c.crisis_refs, [])
		self.assertEquals(c.person_refs, [])
		self.assertEquals(c.model_id, model_id)

	def test_org_model_3 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		model_id = "this_id"
		c1 = Organization.Organization(name = name,
									   model_kind = model_kind,
									   description = description,
									   city = city,
									   country = country,
									   model_id = model_id
									   )
		c1.put()
		c2 = Organization.Organization(name = name,
									   model_kind = model_kind,
									   description = description,
									   city = city,
									   country = country,
									   model_id = model_id
									   )
		c2.put()
		rows = db.GqlQuery("SELECT * FROM Organization")
		self.assertEquals(rows.count(), 2)

	def test_organization_getLink_1 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		model_id = "this_id"
		c = Organization.Organization(name = name,
									  model_kind = model_kind,
									  description = description,
									  city = city,
									  country = country,
									  model_id = model_id
									  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM Organization")
		c = rows.get()
		self.assertEquals(c.getLink(), '/organizations/this_id.html')

	def test_organization_getLink_2 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		model_id = "ninja_cupcakes"
		c = Organization.Organization(name = name,
									  model_kind = model_kind,
									  description = description,
									  city = city,
									  country = country,
									  model_id = model_id
									  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM Organization")
		c = rows.get()
		self.assertEquals(c.getLink(), '/organizations/ninja_cupcakes.html')

	def test_organization_getLink_3 (self) :
		name = "test_name"
		model_kind = "natural"
		description = "Here is a Crisis"
		city = "Somewhere"
		country = "USA"
		model_id = "the_beatles"
		c = Organization.Organization(name = name,
									  model_kind = model_kind,
									  description = description,
									  city = city,
									  country = country,
									  model_id = model_id
									  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM Organization")
		c = rows.get()
		self.assertEquals(c.getLink(), '/organizations/the_beatles.html')

