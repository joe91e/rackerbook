#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

"""
	To test the program:
	% python TestImport.py >& TestImport.out
	% chmod ugo+x TestImport.py
	% TestImport.py >& TestImport.out
"""

# -------
# imports
# -------

import sys
import os

sys.path.append("..")

import StringIO
import unittest
import People
import Organization
import Crisis
from importXML import *
import xml.etree.ElementTree as ET
from Link import *

from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

# using test/outline_test.xml

class TestImport2 (unittest.TestCase) :
	
	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
	
	def tearDown(self):
		self.testbed.deactivate()
	
	
	def test_importDocuments_1 (self):
		x = importXML()
		x.importDocuments("world-crises.xml")
		rows = db.GqlQuery("SELECT * FROM People WHERE name = 'Yingluck Shinawatra'")
		self.assertTrue(rows.count() > 0)
		p = rows.get()
		self.assertEquals("Bangkok", p.city)

	def test_getMedia_1 (self):
		x = importXML()
		data = {}
		s = """
			<elephant>
			<images>
			<image>
			<source>http://media.cleveland.com/nationworld_impact/photo/california-wildfires-2jpg-2ba436abbe035ace.jpg</source>
			<description>California Wildfires</description>
			</image>
			</images>
			</elephant>
			"""
		tree = ET.fromstring(s)
		x.getMedia(tree, data)
		
		assert len(data['images']) == 1
		assert type(data['images'][0]) == db.Key
		assert type(db.get(data['images'][0])) == Link
		
		l = Link(url="http://google.com", description="blah")
		key = l.put()
		assert db.get(key).url == "http://google.com"
		
		self.assertEquals(u"http://media.cleveland.com/nationworld_impact/photo/california-wildfires-2jpg-2ba436abbe035ace.jpg", db.get(data['images'][0]).url)
		
	def test_getMedia_2 (self):
		x = importXML()
		data = {}
		s = """
			<elephant>
			<videos>
				<youtube>9899z9LzO2M</youtube>
			</videos>
			</elephant>
			"""
		tree = ET.fromstring(s)
		x.getMedia(tree, data)
		self.assertEquals("9899z9LzO2M", data['videos_youtube'][0])
		
	def test_getMedia_3 (self):
		x = importXML()
		data = {}
		s = """
			<elephant>
			<maps>
				<map>
					<source>http://www.esri.com/news/arcnews/fall05articles/fall05gifs/gis-volunteers/gv1-lg.jpg</source>
					<description>This map depicts the location of Coast Guard air evacuations during the early days of Hurricane Katrina rescue operations.</description>
				</map>
			</maps>
			</elephant>
			"""
		tree = ET.fromstring(s)
		x.getMedia(tree, data)
		self.assertEquals(u"http://www.esri.com/news/arcnews/fall05articles/fall05gifs/gis-volunteers/gv1-lg.jpg", db.get(data['maps'][0]).url)