#!/usr/bin/env python

# -------------------------------
# Love Muffin
# -------------------------------

# -------
# imports
# -------

import sys
import os

import StringIO
import unittest
import People
from Link import Link
from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.ext import testbed

class TestPeopleModel (unittest.TestCase) :
	
	def setUp(self):
		self.testbed = testbed.Testbed()
		self.testbed.activate()
		self.testbed.init_datastore_v3_stub()
		self.testbed.init_memcache_stub()
	
	def tearDown(self):
		self.testbed.deactivate()
	
	def test_people_model_1 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		state = "TX"
		country = "USA"
		
		images = []
		link = Link(url = db.Link("http://www.sample.com"),
					description = "A samle URL")
		linkid = link.put()
		images.append(linkid)
		
		maps = []
		maps.append(linkid)
		
		videos_youtube = ["Id"]
		
		social_youtube = ["ID"]
		
		citations = []
		citations.append(linkid)
		external_links = []
		external_links.append(linkid)
		
		crisis_refs = ["no ref"]
		organization_refs = ["no ref"]
		model_id = "this model"
		
		c = People.People(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  state = state,
						  country = country,
						  images = images, 
						  maps = maps,
						  videos_youtube = videos_youtube,
						  social_youtube = social_youtube,
						  citations = citations,
						  external_links = external_links,
						  organization_refs = organization_refs,
						  crisis_refs = crisis_refs,
						  model_id = model_id
						  )
		self.assertEquals(c.name, name)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.state, state)
		self.assertEquals(c.country, country)
		self.assertEquals(c.images, images)
		self.assertEquals(c.maps, maps)
		self.assertEquals(c.videos_youtube, videos_youtube)
		self.assertEquals(c.social_youtube, social_youtube)
		self.assertEquals(c.citations, citations)
		self.assertEquals(c.external_links, external_links)
		self.assertEquals(c.organization_refs, organization_refs)
		self.assertEquals(c.crisis_refs, crisis_refs)
		self.assertEquals(c.model_id, model_id)
		"""
		c.put()
		rows = db.GqlQuery("SELECT * FROM People")
		c = rows.get()
		"""
		key = c.put()
		c = db.get(key)
		self.assertEquals(c.name, name)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.state, state)
		self.assertEquals(c.country, country)
		self.assertEquals(c.images, images)
		self.assertEquals(c.maps, maps)
		self.assertEquals(c.videos_youtube, videos_youtube)
		self.assertEquals(c.social_youtube, social_youtube)
		self.assertEquals(c.citations, citations)
		self.assertEquals(c.external_links, external_links)
		self.assertEquals(c.organization_refs, organization_refs)
		self.assertEquals(c.crisis_refs, crisis_refs)
		self.assertEquals(c.model_id, model_id)
	
	
	def test_people_model_2 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "this model"
		c = People.People(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  model_id = model_id
						  )
		self.assertEquals(c.name, name)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, [])
		self.assertEquals(c.maps, [])
		self.assertEquals(c.videos_youtube, [])
		self.assertEquals(c.social_youtube, [])
		self.assertEquals(c.citations, [])
		self.assertEquals(c.external_links, [])
		self.assertEquals(c.organization_refs, [])
		self.assertEquals(c.crisis_refs, [])
		self.assertEquals(c.model_id, model_id)
		c.put()
		rows = db.GqlQuery("SELECT * FROM People")
		c = rows.get()
		self.assertEquals(c.name, name)
		self.assertEquals(c.model_kind, model_kind)
		self.assertEquals(c.description, description)
		self.assertEquals(c.city, city)
		self.assertEquals(c.images, [])
		self.assertEquals(c.maps, [])
		self.assertEquals(c.videos_youtube, [])
		self.assertEquals(c.social_youtube, [])
		self.assertEquals(c.citations, [])
		self.assertEquals(c.external_links, [])
		self.assertEquals(c.organization_refs, [])
		self.assertEquals(c.crisis_refs, [])
		self.assertEquals(c.model_id, model_id)
		c.delete()
	
	def test_people_model_3 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "this model"
		c1 = People.People(name = name,
						   model_kind = model_kind,
						   description = description,
						   city = city,
						   country = country,
						   model_id = model_id
						   )
		c1.put()
		c2 = People.People(name = name,
						   model_kind = model_kind,
						   description = description,
						   city = city,
						   country = country,
						   model_id = model_id
						   )
		c2.put()
		rows = db.GqlQuery("SELECT * FROM People")
		self.assertEquals(rows.count(), 2)
		c1.delete()
		c2.delete()
	
	def test_people_model_4 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "this model"
		c1 = People.People(key_name = model_id,
						   name = name,
						   model_kind = model_kind,
						   description = description,
						   city = city,
						   country = country,
						   model_id = model_id
						   )
		c1.put()
		c2 = People.People(key_name = model_id,
						   name = name,
						   model_kind = model_kind,
						   description = description,
						   city = city,
						   country = country,
						   model_id = model_id
						   )
		c2.put()
		rows = db.GqlQuery("SELECT * FROM People")
		self.assertEquals(rows.count(), 1)
	
	def test_people_model_getLocationString_1 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "this model"
		c1 = People.People(name = name,
						   model_kind = model_kind,
						   description = description,
						   city = city,
						   country = country,
						   model_id = model_id
						   )
		self.assertEquals("Austin USA", c1.getLocationString())

	def test_people_model_getLocationString_2 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		state = "Texas"
		country = "USA"
		model_id = "this model"
		c1 = People.People(name = name,
						   model_kind = model_kind,
						   description = description,
						   city = city,
						   state = state,
						   country = country,
						   model_id = model_id
						   )
		self.assertEquals("Austin, Texas USA", c1.getLocationString())

	def test_people_model_getLocationString_3 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		state = "Texas"
		country = "USA"
		model_id = "this model"
		c1 = People.People(name = name,
						   model_kind = model_kind,
						   description = description,
						   state = state,
						   country = country,
						   model_id = model_id
						   )
		self.assertEquals("Texas USA", c1.getLocationString())
	
	def test_people_getLink_1 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "dumb_celeb"
		c = People.People(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  model_id = model_id
						  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM People")
		c = rows.get()
		self.assertEquals(c.getLink(), '/people/dumb_celeb.html')

	def test_people_getLink_2 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "graham_benevelli"
		c = People.People(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  model_id = model_id
						  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM People")
		c = rows.get()
		self.assertEquals(c.getLink(), '/people/graham_benevelli.html')

	def test_people_getLink_3 (self) :
		name = "Test Name"
		model_kind = "Celeb"
		description = "Stupid but popular"
		city = "Austin"
		country = "USA"
		model_id = "eric_cartman"
		c = People.People(name = name,
						  model_kind = model_kind,
						  description = description,
						  city = city,
						  country = country,
						  model_id = model_id
						  )
		c.put()
		rows = db.GqlQuery("SELECT * FROM People")
		c = rows.get()
		self.assertEquals(c.getLink(), '/people/eric_cartman.html')

