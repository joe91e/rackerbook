
from google.appengine.ext import db
import sys
sys.path.append("./Model")
from Data import Data
from Crisis import Crisis
from People import People
from Organization import Organization
from Link import Link
	
db.delete(Crisis.all(keys_only=True))
db.delete(People.all(keys_only=True))
db.delete(Organization.all(keys_only=True))
db.delete(Link.all(keys_only=True))