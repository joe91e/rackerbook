from google.appengine.ext import db
from Common import Common

class People(Common):
	crisis_refs = db.StringListProperty()
	organization_refs = db.StringListProperty()
	
	def getLink(self):
		return '/people/' + self.model_id + '.html'

	def __eq__(self, other):
		return (isinstance(other, self.__class__)
				and self.__dict__ == other.__dict__)