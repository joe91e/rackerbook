from google.appengine.ext import db
from Common import Common

class Organization(Common):
	address = db.StringProperty()
	e_mail = db.StringProperty()
	phone = db.StringProperty()
	crisis_refs = db.StringListProperty()
	person_refs = db.StringListProperty() 
	
	def getLink(self):
		return '/organizations/' + self.model_id + '.html'

	def __eq__(self, other):
		return (isinstance(other, self.__class__)
				and self.__dict__ == other.__dict__)
