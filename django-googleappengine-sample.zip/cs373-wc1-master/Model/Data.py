from google.appengine.ext import db

class Data(db.Model):
	data_list = db.ListProperty(item_type=db.Text)
	key_list  = db.ListProperty(item_type=db.Text)
	keyword_list = db.ListProperty(item_type=db.Text)

	def __init__(self, tuples = [], **kwargs):
		db.Model.__init__(self, **kwargs)
		if(tuples is not None):
			for t in tuples:
				assert type(t) == tuple
				self.append_tuple((t[0], t[1], t[2]))
	
	def __len__(self) :
		assert len(self.data_list) == len(self.key_list)
		assert len(self.data_list) == len(self.keyword_list)
		return len(self.data_list)
		
	def __iter__(self) :
		data_it = iter(self.data_list)
		keyword_it = iter(self.keyword_list)
		key_it = iter(self.key_list)
		
		while(1) :
			yield (data_it.next(), keyword_it.next(), key_it.next())
	
	def __getitem__(self, i):
		return self.get_tuple(i)
	
	def __setitem__(self, i, v):
		self.insert_tuple(i, v)
		
	def __eq__(self, other):
		if (type(other) == Data):
			return self.data_list == other.data_list and self.key_list == other.key_list and self.keyword_list == other.keyword_list
		if (type(other) == list):
			tuples = []
			it = iter(self)
			for x in it:
				tuples.append(x)
			return tuples == other
		return false
	
	def append_tuple(self, t) :
		assert type(t) == tuple
		assert len(t) == 3
		assert type(t[0]) == str
		assert type(t[1]) == str
		assert type(t[2]) == str
		
		self.data_list.append(db.Text(t[0]))
		self.keyword_list.append(db.Text(t[1]))
		self.key_list.append(db.Text(t[2]))
	
	def insert_tuple(self, i, t) :
		assert type(t) == tuple
		assert len(t) == 3
		assert type(t[0]) == str
		assert type(t[1]) == str
		assert type(t[2]) == str
		assert len(self.data_list) > i
		self.data_list[i] = db.Text(t[0])
		self.keyword_list[i] = db.Text(t[1])
		self.key_list[i] = db.Text(t[2])
		
		
	def get_tuple(self, i) :
		"""
		Returns the tuple at index i in this object
		"""
		assert type(i) == int
		assert len(self.data_list) > i
		result = (self.data_list[i], self.keyword_list[i], self.key_list[i])
		return result
	
	def remove_tuple(self, i) :
		"""
		Returns the tuple at index i in this object
		then removes the data
		"""
		assert type(i) == int
		assert len(self.data_list) >= i
		result = self.get_tuple(i)
		del self.data_list[i]
		del self.keyword_list[i]
		del self.key_list[i]
		return result
			
	def contains(self, t):
		if(type(t) is not tuple):
			return False;
		it = iter(self)
		for x in it:
			if (t == x):
				return True
		return False
		