from google.appengine.ext import db

class Link(db.Model):
	url = db.LinkProperty(required=True)
	description = db.StringProperty(required=True)

	def __eq__(self, other):
		return (isinstance(other, self.__class__)
				and self.__dict__ == other.__dict__)