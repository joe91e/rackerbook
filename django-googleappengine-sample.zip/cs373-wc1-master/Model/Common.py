from google.appengine.ext import db
from Link import Link
import re

class Common(db.Model):
	
	name = db.StringProperty(required=True)
	alternate_names = db.StringProperty()
	model_kind = db.StringProperty(required=True)
	description = db.TextProperty(required=True)
	latitude = db.StringProperty()
	longitude = db.StringProperty()
	city = db.StringProperty()
	state = db.StringProperty()
	country = db.StringProperty(required=True)
	
	images = db.ListProperty(db.Key)
	maps = db.ListProperty(db.Key)
	videos_youtube = db.StringListProperty()
	videos_vimeo = db.StringListProperty()
	social_facebook = db.StringListProperty()
	social_twitter = db.StringListProperty()
	social_youtube = db.StringListProperty()
	
	citations = db.ListProperty(db.Key)
	external_links = db.ListProperty(db.Key)
	
	model_id = db.StringProperty(required=True)
	
	max_length = 140

	def getLocationString(self):
		ret = ""
		if(self.city):
			ret = ret + self.city
		if(self.state):
			if(ret != ""):
				ret = ret + ", " + self.state
			else:
				ret = self.state
		if(self.country):
			if(ret != ""):
				ret = ret + " " + self.country
			else:
				ret = self.country
		if(self.latitude and self.longitude):
			if(ret != ""):
				ret = ret + " " + self.latitude + " " + self.longitude
			else :
				ret = self.latitude + " " + self.longitude
		return ret

	def getHighlight(self, field, query):
		item = self.getField(field)
		if isinstance(item, basestring):
			return (self.capitalize(field), self.highlightString(item, query))
		if isinstance(item, list):
			return (self.capitalize(field), self.highlightList(item, query))
	
	def getField(self, field):
		return getattr(self, field)

	def highlightString(self, text, query):
		if isinstance(query, str):
			split = re.split(query, text)
			if(len(split) == 1):
				return text
			text = '<strong style="background-color:#FFFF00;">' + query + '</strong>'
			text = split[0][-30:] + text
			text = text + split[1][:(self.max_length-len(text))]
			if(len(split[0]) > 30):
				text = '...' + text
			if(len(split[1]) > 140-len(query)-len(split[0])):
					text = text + '...'
		else:
			index = len(text)
			for q in query:
				curIndex = text.lower().find(q.lower())
				if curIndex != -1:
					index = min(index, curIndex)
			t1 = text[:index]
			t2 = text[index:]
			if t1 > 30:
				t1 = '...' + t1[-30:]
			if t2 > 143 - len(t1):
				t2 = t2[:143 - len(t1)] + '...'
			text = t1 + t2
			for q in query:
				text = text.replace(q, '<strong style="background-color:#FFFF00;">' + q + '</strong>')
		return text
	
	def highlightList(self, list, query):
		if isinstance(query, str):
			index = None
			for i in range(0, len(list)):
				if query.lower() in list[i].lower():
					index = i
					break
		else:
			listIndex = None
			for i in range(0, len(list)):
				for q in query:
					if q.lower() in list[i].lower():
						listIndex = i
						break
		ret = '<ul>'
		if i == 0:
			i = 1
		if i == len(list) - 1:
			i = len(list) - 2
		list = list[i-1:i+2]
		for item in list:
			ret = ret + '<li>' + self.highlightString(item, query) + '</li>'
		ret = ret + '</ul>'
		return ret

	def capitalize(self, text):
		return text.replace('_', ' ').title()

	def __eq__(self, other):
		return (isinstance(other, self.__class__)
				and self.__dict__ == other.__dict__)