from google.appengine.ext import db
from Common import Common

class Crisis (Common):
	start_date = db.StringProperty()
	end_date = db.StringProperty()
	deaths = db.IntegerProperty()
	missing = db.IntegerProperty()
	injured = db.IntegerProperty()
	displaced = db.IntegerProperty()
	economic_impact = db.IntegerProperty(required=True)
	ways_to_help = db.StringListProperty()
	resources_needed = db.StringListProperty()
	organization_refs = db.StringListProperty()
	person_refs = db.StringListProperty()
		
	def getLink(self):
		return '/crises/' + self.model_id + '.html'

	def __eq__(self, other):
		return (isinstance(other, self.__class__)
				and self.__dict__ == other.__dict__)