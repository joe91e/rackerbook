import sys
import os
sys.path.append('Model')

sys.path.append("/Applications/GoogleAppEngineLauncher.app/Contents/Resources/GoogleAppEngine-default.bundle/Contents/Resources/google_appengine")
sys.path.append("./test")
sys.path.append("./Model")

from google.appengine.ext import db

from importXML import *

x = importXML()
x.importDocuments("world-crises.xml")