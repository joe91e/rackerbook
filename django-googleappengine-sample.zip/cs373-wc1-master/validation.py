import sys
import os

sys.path.append("./minixsv")

import getopt
from genxmlif          import GenXmlIfError
from xsvalErrorHandler import ErrorHandler, XsvalError
from minixsv           import *
from pyxsval           import *

class validation():

	def validateXSD(self, xmlInputFilename, xsdFileName):
		"""
			Validate a XML against a File
			xmlInputFilename: file name
			xsdFileName: file name
		"""
		try:
			parseAndValidateXmlInput (xmlInputFilename, xsdFileName)
		except IOError, errstr:
			print errstr
			return False
		except GenXmlIfError, errstr:
			print errstr
			return False
		except XsvalError, errstr:
			print errstr
			return False
		return True

	def validateXSDString(self, xmlText, xsdFileName):
		"""
			Valideate an XML against a XSD
			xmlText: File string
			xsdFileName: File string
		"""
		f = open(xsdFileName, 'r')
		xsdText = f.read()
		try:
			parseAndValidateXmlInputString (xmlText, xsdText)
		except IOError, errstr:
			print errstr
			return False
		except GenXmlIfError, errstr:
			print errstr
			return False
		except XsvalError, errstr:
			print errstr
			return False
		return True