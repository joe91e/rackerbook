#! usr/bin/env python

# globals
RANKING = {}
PHRASE = []
CHECKED = False
MULTIPLE = False

from google.appengine.ext import db
from Data import Data

def getDataModel():
	rows = db.GqlQuery("SELECT * FROM Data").fetch(None)
	assert len(rows) <= 1
	if(len(rows) == 0):
		return Data()
	data = rows[0]
	return data

def get_substrings(strings) :
	substrings = []
	for i in range(0, len(strings)):
		result = ""
		for j in range(i, len(strings)):
			# append all strings from i to j in strings
			result += strings[j]
			substrings.append(result)
			result += " "
	substrings.sort()
	substrings.sort(key=len, reverse=True)
	return substrings

def get_rank(target, text):
	# returns an int indicating the strength of any match found
	# find the longest matching substring
	strings = target.split()
	substrings = get_substrings(strings) # O(N^2)
	longest_match = 0
	for string in substrings:
		if(string in text):
			longest_match = len(string.split())
			break
	
	# find the number words matched
	num_matches = 0
	for string in target.split():
		if(string in text):
			num_matches += 1
	return longest_match + num_matches
	
def Search(phrase):
	magicObj = getDataModel()
	temp = []
	for (text, keyword, model_key) in magicObj:
		rank = get_rank(phrase.lower(), text.lower())
		# if rank is not 0, than it is at least a partial match
		if((rank != 0) and should_append(temp, model_key, rank, keyword)):
			temp.append((keyword, model_key, rank))
	# temp now contains a list of all matches
	temp.sort(key=(lambda x : x[2]), reverse=True)
	
	# remove the rank and return the list
	result = []
	for (keyword, model_key, rank) in temp:
		result.append((keyword, model_key))
	return result
	
	"""
	global MULTIPLE
	result = []
	if(isMultipleWords(phrase)):
		MULTIPLE = True
		temp = MultiWordSearch(phrase, magicObj, result)
	
	temp = SearchHelper(phrase, magicObj, result)
	# print temp
	return Org_by_rank(temp)
	"""
	
def should_append(temp, model_key, rank, keyword) :
	for i in range(len(temp)):
		tup = temp[i]
		if(tup[1] == model_key):
			if (tup[2] > rank):
				return False
			else:
				temp[i] = (keyword, tup[1], rank)
				return False
	 
	return True
	
def SearchHelper(phrase, magicObj, result):
	global CHECKED
	it = iter(magicObj)
	while(True):
		try:
			tup = it.next()
			word = tup[0]
			# print word
			# print phrase
			if phrase.lower() in word.lower():
				if not CHECKED:
					# print ("Checked == " + str(CHECKED) + " going to ranking")
					ranking(phrase.lower(), word.lower(), tup)
				if(str(tup[1]) not in result):
					result.append(tup[1])
				# print result
		except StopIteration :
			break
	return result


def isMultipleWords(phrase):
	sent = phrase.split()
	if(len(sent) > 1):
		return True	
	return False
		

def MultiWordSearch(sent, magicObj, result):
	global PHRASE, CHECKED
	words = sent.split()
	PHRASE = words
	wcount = 0
	for word in words:
		if wcount > 0:
			CHECKED = True
		SearchHelper(word, magicObj, result)
		wcount+=1
		#print result
	return result

# rating will be based on what is found, in the case of a single word being
# searched, rating will be high if the exact word is found, but lower if the 
# word is found in another word.  i.e. 'is' is in this but is not an exact
# match.  However, for multiple words in the same search line, an exact match 
# will be the highest rating and then points will go down from there.  
# once rating is done, it will be able to reorder the results list by rating
# to make Graham's part of the project easier.

def ranking(word, target, tup):
	#ranking best is 0 one word found in the exact way it is searched for is 0
	#found in another word is 1 i.e. searched "it" found "it" == 0, 
	#found "it" in "fit" == 1.
	# for Multiple words if each word is found as an exact match and not inside 
	# or as a part of another word, its rating will be 1 if the entire string 
	# is found in order in the exact way it is searched its rating will be 0. 
	rate = 1
	global RANKING, MULTIPLE
	targetlist = target.split()
	it = iter(targetlist)
	# words already found to exist in current target
	if MULTIPLE :
		global PHRASE
		rate = len(PHRASE)
		# print "Multiple words"
		pl = 0
		bestRate = rate
		while 1 :
			try :
				if (PHRASE[pl] == it.next()) :
					# print "Match found"
					end = False
					if rate > 0 :
						rate-=1
					pl += 1
					while not end :
						try :
							if PHRASE[pl] != it.next() :
								pl = 0
								bestRate = rate
								rate = len(PHRASE)
								break
							if rate > 0 :
								rate -= 1
							pl+=1
							end = (pl == len(PHRASE))
						except StopIteration :
								break
					if pl == len(PHRASE) :
						# print "done"
						break
					# check for rest of words in sequence.  if not in sequence
					# back up to first word continue to check for next word in 
					# search sequence keep rating number but only change if a 
					# sequence is found need new method for this.
			except StopIteration:
				break
		rate = min(bestRate, rate)
	else :# single word search 
		# print "single words"
		found = False
		while 1 and not found:
			try:
			 	if word == it.next():
			 		rate -= 1
			 		found = True
			except StopIteration:
			 	break
			 	
	RANKING.update({str(tup[1]): rate})


def Org_by_rank(result) :
	global RANKING
	finResult = []
	keys = RANKING.keys()
	# print keys
	vals = RANKING.values()
	# print vals
	end = max(vals)+1
	tracker = 0
	while ((len(vals) > 0) and (tracker <= end)):
		x = vals.count(tracker)
		if x > 0 :
			for i in range(x) :
				place  = vals.index(tracker)
				finResult.append(keys.pop(place))
				vals.pop(place)
		tracker+=1
	#print finResult
	return finResult

# tests
#
#
#MO = [("This is awesome", 'dan_g'), ("No It tIs NoT, yOu DoLt!", 'far_fennuggen'), ("NaNANaNaNaNaNaNa BoBObObObObObO" , 'Kev_vnut')]
#result = Search('IS', MO)
#print MO
#print result
#print result == ['dan_g', 'far_fennuggen']
#print RANKING
#RANKING = {}
#
#MO1 = [("THis will be awesome", 'anry'), ("Hello, world",'ello'),("Thu Wong Fu thanks for everything, Julie Newmar",'thu'),("Monster This will be Great Godzilla",'Gorjira'),("This is the Best Eva!",'turdburgler')]
#result = Search('this will be', MO1)
#print MO1
#print result
#print result == ['anry','Gorjira','turdburgler']
#print RANKING
