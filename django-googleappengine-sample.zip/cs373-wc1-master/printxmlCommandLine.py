import sys
import os
sys.path.append("/Applications/GoogleAppEngineLauncher.app/Contents/Resources/GoogleAppEngine-default.bundle/Contents/Resources/google_appengine")
sys.path.append('Model')

import StringIO
import unittest
from importXML import *

os.environ['APPLICATION_ID'] = ' wc1'

datastore_file = './temp/datastore'
history_file = './temp/datastore.hist'
from google.appengine.api import apiproxy_stub_map,datastore_file_stub
apiproxy_stub_map.apiproxy = apiproxy_stub_map.APIProxyStubMap() 
stub = datastore_file_stub.DatastoreFileStub('wc1', datastore_file, history_file, trusted = True)
apiproxy_stub_map.apiproxy.RegisterStub('datastore_v3', stub)

from exportXML import exportXML

print 'Content-Type: text/xml'
print ''

x = importXML()
x.importDocuments("world-crises.xml")

e = exportXML()
e.getXML()
