cs373-wc1
=========

World Crisis Database: Love Muffin