import os
import sys

sys.path.append("../Model")

from google.appengine.ext import db

from People import People
from Crisis import Crisis
from Organization import Organization 
from Link import Link

def formatKeys(query, keysTuples, template_values):
	query = query.split()
	keys = [k[1] for k in keysTuples]
	records = populateSearchByKeys(keys)
	for i in range(0, len(keysTuples)):
		keys[i] = (keysTuples[i][0], records[i])
	populateSearchByRecords(query, keys, template_values)

def getField(query, records):
	for i in range(0, len(records)):
		records[i] = getFieldTuple(query, records[i])
	return records

def getFieldTuple(query, record):
	fieldOrder = ['name', 'description', 'alternate_names', 'ways_to_help', 'resources_needed', 'city', 'state', 'country']
	query = query.lower()
	for field in fieldOrder:
		try:
			attr = getattr(record, field).lower()
			for q in query:
				if q in attr:
					return (record, field)
		except AttributeError:
			pass

def populateSearchByKeys(keys):
	crises = db.GqlQuery("SELECT * FROM Crisis")
	orgs = db.GqlQuery("SELECT * FROM Organization")
	people = db.GqlQuery("SELECT * FROM People")
	for crisis in crises:
		while True:
			try:
				keys[keys.index(crisis.model_id)] = crisis
			except ValueError:
				break
	for org in orgs:
		while True:
			try:
				keys[keys.index(org.model_id)] = org
			except ValueError:
				break
	for person in people:
		while True:
			try:
				keys[keys.index(person.model_id)] = person
			except ValueError:
				break
	return keys

def populateSearchByRecords(query, records, template_values):
	ret = [];
	for record in records:
		if isinstance(record[1], str) or record is None:
			continue
		try:
			temprec = {}
			temprec['name'] = record[1].name
			temprec['link'] = record[1].getLink()
			temprec['text'] = record[1].getHighlight(record[0], query)
			ret.append(temprec)
		except AttributeError:
			continue
	template_values['search'] = ret
