import os
import sys

sys.path.append("../Model")

from google.appengine.ext import db

from People import People
from Crisis import Crisis
from Organization import Organization 
from Link import Link

def eliminateHtmlTag(address):
	if (address[-5:] == '.html'):
		return address[0:-5]
	else:
		return address

def getLinkFromName(name, folder):
	return '/' + folder + '/' + name.lower().replace(' ', '_')

def getHeader():
	template_values = {}
	# Crises
	crises = []
	q = Crisis.all()
	active = True
	for crisis in q.run():
		c = {}
		c['name'] = crisis.name
		c['url'] = getLinkFromName(crisis.model_id, 'crises')
		c['description'] = crisis.description
		c['model_id'] = crisis.model_id
		c['active'] = active
		active = False
		crises.append(c)
	if(len(crises) == 0):
		c = {}
		c['name'] = 'None Yet'
		c['url'] = '/'
		crises.append(c)
	template_values["crises"] = crises
	# Organizations
	organizations = []
	q = Organization.all()
	active = True
	for org in q.run():
		c = {}
		c['name'] = org.name
		c['url'] = getLinkFromName(org.model_id, 'organizations')
		c['description'] = org.description
		c['model_id'] = org.model_id
		c['active'] = active
		active = False
		organizations.append(c)
	if(len(organizations) == 0):
		c = {}
		c['name'] = 'None Yet'
		c['url'] = '/'
		organizations.append(c)
	template_values["organizations"] = organizations
	# People
	people = []
	q = People.all()
	active = True
	for person in q.run():
		c = {}
		c['name'] = person.name
		c['url'] = getLinkFromName(person.model_id, 'people')
		c['description'] = person.description
		c['model_id'] = person.model_id
		c['active'] = active
		active = False
		people.append(c)
	if(len(people) == 0):
		c = {}
		c['name'] = 'None Yet'
		c['url'] = '/'
		people.append(c)
	template_values["people"] = people
	return template_values

def populateLinks(obj):
	obj.imagesLinks = []
	for link in obj.images:
		obj.imagesLinks.append(Link.get(link))
	obj.mapsLinks = []
	for link in obj.maps:
		obj.mapsLinks.append(Link.get(link))
	obj.citationsLinks = []
	for link in obj.citations:
		obj.citationsLinks.append(Link.get(link))
	obj.external_linksLinks = []
	for link in obj.external_links:
		obj.external_linksLinks.append(Link.get(link))

